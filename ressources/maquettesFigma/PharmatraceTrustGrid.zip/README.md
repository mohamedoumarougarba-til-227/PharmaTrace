
  # PharmatraceTrustGrid (Community)

  This is a code bundle for PharmatraceTrustGrid (Community). The original project is available at https://www.figma.com/design/cxlC1sp5NdhYLqJl2Du5kq/PharmatraceTrustGrid--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  