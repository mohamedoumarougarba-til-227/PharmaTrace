import { useNavigate } from 'react-router';

export function AuthenticResultScreen() {
  const navigate = useNavigate();
  return (
    <div className="w-[390px] h-[844px] flex flex-col" style={{ backgroundColor: '#27AE60' }}>
      {/* Status Bar */}
      <div className="h-11 flex items-center justify-between px-5 text-white">
        <span className="text-[15px]" style={{ fontFamily: 'Inter', fontWeight: 700 }}>9:41</span>
        <div className="flex items-center gap-1.5">
          <span className="text-[13px]">📶</span>
          <span className="text-[13px]">📶</span>
          <span className="text-[13px]">🔋</span>
        </div>
      </div>

      {/* Top Bar */}
      <div className="h-14 flex items-center justify-between px-5">
        <button
          onClick={() => navigate('/scanner')}
          className="text-[14px] text-white"
        >
          ← Retour
        </button>
        <h1 className="text-[17px] text-white" style={{ fontFamily: 'Inter', fontWeight: 700 }}>
          PharmaTrace
        </h1>
        <div className="w-16"></div>
      </div>

      {/* Icon Area */}
      <div className="flex justify-center mt-11">
        <div
          className="w-[92px] h-[92px] rounded-full bg-white flex items-center justify-center text-[50px]"
          style={{
            boxShadow: '0 0 0 8px rgba(255,255,255,0.20), 0 0 0 18px rgba(255,255,255,0.10)',
            color: '#27AE60'
          }}
        >
          ✓
        </div>
      </div>

      {/* Verdict */}
      <div className="px-6 mt-4.5 text-center">
        <h2 className="text-[34px] text-white" style={{ fontFamily: 'Inter', fontWeight: 900, letterSpacing: '1px' }}>
          ✓  AUTHENTIQUE
        </h2>
        <p className="text-[14px] text-white mt-2" style={{ opacity: 0.8 }}>
          Médicament vérifié avec succès
        </p>
      </div>

      {/* Medicine Card */}
      <div
        className="mx-4 mt-5.5 bg-white rounded-2xl p-5.5"
        style={{ boxShadow: '0 8px 32px rgba(0,0,0,0.15)' }}
      >
        <div className="flex items-center gap-2 border-b pb-3.5 mb-4" style={{ borderColor: '#DCE6F0' }}>
          <span
            className="text-[10px] px-2.5 py-1 rounded-full"
            style={{
              backgroundColor: '#E8F8EC',
              color: '#27AE60',
              fontFamily: 'Inter',
              fontWeight: 700,
              textTransform: 'uppercase'
            }}
          >
            ENREGISTRÉ DANS LE SYSTÈME
          </span>
        </div>

        <h3 className="text-[22px]" style={{ fontFamily: 'Inter', fontWeight: 700, color: '#1A3A5C' }}>
          Amoxicilline 500mg
        </h3>
        <p className="text-[13px] mt-1" style={{ color: '#666666' }}>
          Amoxicilline trihydrate
        </p>

        <div className="mt-4 space-y-0">
          {[
            { label: 'Fabricant', value: 'Labo Niger Pharma', bold: true },
            { label: 'Fabrication', value: '15 jan. 2026', bold: false },
            { label: 'Expiration', value: '15 jan. 2028', bold: true, color: '#27AE60' },
          ].map((row, i) => (
            <div
              key={i}
              className="flex items-center justify-between h-11 border-b text-[14px]"
              style={{ borderColor: '#F7F9FC' }}
            >
              <span style={{ color: '#666666' }}>{row.label}</span>
              <span
                style={{
                  fontFamily: 'Inter',
                  fontWeight: row.bold ? 600 : 400,
                  color: row.color || '#1A1A1A'
                }}
              >
                {row.value}
              </span>
            </div>
          ))}

          <div className="flex items-center justify-between h-11 border-b text-[14px]" style={{ borderColor: '#F7F9FC' }}>
            <span style={{ color: '#666666' }}>Statut</span>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#27AE60' }}></div>
              <span style={{ fontFamily: 'Inter', fontWeight: 600, color: '#1A1A1A' }}>En pharmacie</span>
            </div>
          </div>

          <div className="flex items-center justify-between h-11 text-[13px]">
            <span style={{ color: '#666666' }}>Dernière étape</span>
            <span style={{ color: '#1A1A1A' }}>Pharmacie Centrale — 20/05/2026</span>
          </div>
        </div>
      </div>

      {/* Bottom Button */}
      <button
        onClick={() => navigate('/scanner')}
        className="mx-4 mt-5 h-[52px] rounded-lg bg-white text-[15px]"
        style={{
          color: '#27AE60',
          fontFamily: 'Inter',
          fontWeight: 700,
          border: '2px solid rgba(255,255,255,0.4)'
        }}
      >
        Vérifier un autre médicament
      </button>

      {/* Scan Note */}
      <div className="text-center mt-3.5">
        <p className="text-[11px] text-white" style={{ opacity: 0.4 }}>
          Scan enregistré dans PharmaTrace
        </p>
      </div>

      {/* Home Indicator */}
      <div className="flex justify-center mt-auto pb-2">
        <div className="w-[130px] h-1 rounded-sm bg-white" style={{ opacity: 0.15 }}></div>
      </div>
    </div>
  );
}
