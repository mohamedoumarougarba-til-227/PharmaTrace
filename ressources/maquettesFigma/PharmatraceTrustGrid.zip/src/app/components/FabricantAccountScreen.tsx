import { MobileLayout } from './MobileLayout';
import { ChevronRight, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router';

export function FabricantAccountScreen() {
  const navigate = useNavigate();

  return (
    <MobileLayout
      title="Mon Compte"
      activeTab="compte"
      onTabChange={(tab) => {
        if (tab === 'nouveau') navigate('/fabricant/nouveau-lot');
        if (tab === 'lots') navigate('/fabricant/qr-genere');
        if (tab === 'transferts') navigate('/fabricant/transfert');
      }}
    >
      {/* Profile Header */}
      <div
        className="mx-5 mt-4 p-5 rounded-xl text-center"
        style={{
          backgroundColor: '#FFFFFF',
          boxShadow: '0 2px 12px rgba(0,0,0,0.08)'
        }}
      >
        <div
          className="w-20 h-20 mx-auto rounded-full flex items-center justify-center text-[32px]"
          style={{
            backgroundColor: '#EEF4FB',
            border: '3px solid #2E6DA4'
          }}
        >
          🏭
        </div>
        <div className="text-[20px] mt-3" style={{ fontWeight: 700, color: '#1A3A5C' }}>
          Labo Niger Pharma
        </div>
        <div
          className="inline-block px-3 py-1 rounded-full text-[12px] mt-2"
          style={{
            backgroundColor: '#E8F8EC',
            color: '#27AE60',
            fontWeight: 700
          }}
        >
          ✓ Fabricant agréé
        </div>
      </div>

      {/* Account Info */}
      <div
        className="mx-5 mt-4 rounded-xl overflow-hidden"
        style={{
          backgroundColor: '#FFFFFF',
          boxShadow: '0 2px 12px rgba(0,0,0,0.08)'
        }}
      >
        <div
          className="px-5 py-3"
          style={{
            backgroundColor: '#F7F9FC',
            borderBottom: '1px solid #DCE6F0'
          }}
        >
          <div
            className="text-[11px]"
            style={{
              color: '#2E6DA4',
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '1.5px'
            }}
          >
            INFORMATIONS
          </div>
        </div>

        <AccountMenuItem icon="📧" label="Email" value="contact@nigerpharma.ne" />
        <AccountMenuItem icon="📱" label="Téléphone" value="+227 20 73 45 67" />
        <AccountMenuItem icon="📍" label="Adresse" value="Zone Industrielle, Niamey" />
        <AccountMenuItem icon="🆔" label="N° Agrément" value="FABR-NE-2024-001" isLast />
      </div>

      {/* Statistics */}
      <div
        className="mx-5 mt-4 rounded-xl overflow-hidden"
        style={{
          backgroundColor: '#FFFFFF',
          boxShadow: '0 2px 12px rgba(0,0,0,0.08)'
        }}
      >
        <div
          className="px-5 py-3"
          style={{
            backgroundColor: '#F7F9FC',
            borderBottom: '1px solid #DCE6F0'
          }}
        >
          <div
            className="text-[11px]"
            style={{
              color: '#2E6DA4',
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '1.5px'
            }}
          >
            STATISTIQUES
          </div>
        </div>

        <div className="p-5 grid grid-cols-3 gap-4">
          <StatCard number="142" label="Lots créés" />
          <StatCard number="89" label="Transferts" />
          <StatCard number="98%" label="Conformité" color="#27AE60" />
        </div>
      </div>

      {/* Settings */}
      <div
        className="mx-5 mt-4 rounded-xl overflow-hidden"
        style={{
          backgroundColor: '#FFFFFF',
          boxShadow: '0 2px 12px rgba(0,0,0,0.08)'
        }}
      >
        <SettingsMenuItem icon="🔔" label="Notifications" />
        <SettingsMenuItem icon="🔒" label="Sécurité" />
        <SettingsMenuItem icon="⚙️" label="Paramètres" />
        <SettingsMenuItem icon="❓" label="Aide & Support" isLast />
      </div>

      {/* Logout Button */}
      <div className="mx-5 mt-4 mb-6">
        <button
          onClick={() => navigate('/')}
          className="w-full h-[52px] rounded-lg flex items-center justify-center gap-2 text-[15px]"
          style={{
            backgroundColor: '#FFFFFF',
            border: '2px solid #C0392B',
            color: '#C0392B',
            fontWeight: 700
          }}
        >
          <LogOut size={18} />
          Se déconnecter
        </button>
      </div>
    </MobileLayout>
  );
}

interface AccountMenuItemProps {
  icon: string;
  label: string;
  value: string;
  isLast?: boolean;
}

function AccountMenuItem({ icon, label, value, isLast = false }: AccountMenuItemProps) {
  return (
    <div
      className="px-5 py-3.5 flex items-center gap-3"
      style={{
        borderBottom: isLast ? 'none' : '1px solid #F7F9FC'
      }}
    >
      <span className="text-[20px]">{icon}</span>
      <div className="flex-1">
        <div className="text-[12px]" style={{ color: '#999999' }}>
          {label}
        </div>
        <div className="text-[14px] mt-0.5" style={{ color: '#1A1A1A', fontWeight: 600 }}>
          {value}
        </div>
      </div>
    </div>
  );
}

interface StatCardProps {
  number: string;
  label: string;
  color?: string;
}

function StatCard({ number, label, color = '#1A3A5C' }: StatCardProps) {
  return (
    <div className="text-center">
      <div className="text-[24px]" style={{ fontWeight: 900, color }}>
        {number}
      </div>
      <div className="text-[10px] mt-1" style={{ color: '#666666' }}>
        {label}
      </div>
    </div>
  );
}

interface SettingsMenuItemProps {
  icon: string;
  label: string;
  isLast?: boolean;
}

function SettingsMenuItem({ icon, label, isLast = false }: SettingsMenuItemProps) {
  return (
    <button
      className="w-full px-5 py-4 flex items-center justify-between"
      style={{
        borderBottom: isLast ? 'none' : '1px solid #F7F9FC'
      }}
    >
      <div className="flex items-center gap-3">
        <span className="text-[18px]">{icon}</span>
        <span className="text-[15px]" style={{ color: '#1A1A1A', fontWeight: 600 }}>
          {label}
        </span>
      </div>
      <ChevronRight size={18} style={{ color: '#CCCCCC' }} />
    </button>
  );
}
