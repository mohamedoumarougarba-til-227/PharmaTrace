import { Bell, Factory } from 'lucide-react';
import { useNavigate } from 'react-router';

interface TabBarProps {
  activeTab: 'transferts' | 'stock' | 'scan' | 'compte';
  onTabChange: (tab: 'transferts' | 'stock' | 'scan' | 'compte') => void;
}

function PharmacyTabBar({ activeTab, onTabChange }: TabBarProps) {
  return (
    <div
      className="fixed bottom-0 w-[390px] h-16 flex items-center justify-around border-t"
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: '#DCE6F0',
        boxShadow: '0 -2px 8px rgba(0,0,0,0.06)'
      }}
    >
      <PharmacyTabButton
        emoji="📥"
        label="Transferts"
        active={activeTab === 'transferts'}
        onClick={() => onTabChange('transferts')}
        hasBadge
      />
      <PharmacyTabButton
        emoji="📦"
        label="Stock"
        active={activeTab === 'stock'}
        onClick={() => onTabChange('stock')}
      />
      <PharmacyTabButton
        emoji="🔍"
        label="Scan"
        active={activeTab === 'scan'}
        onClick={() => onTabChange('scan')}
      />
      <PharmacyTabButton
        emoji="👤"
        label="Compte"
        active={activeTab === 'compte'}
        onClick={() => onTabChange('compte')}
      />
    </div>
  );
}

function PharmacyTabButton({ emoji, label, active, onClick, hasBadge = false }: {
  emoji: string;
  label: string;
  active: boolean;
  onClick: () => void;
  hasBadge?: boolean;
}) {
  return (
    <button className="flex flex-col items-center gap-1 relative" onClick={onClick}>
      <div className="relative">
        <span className="text-[18px]">{emoji}</span>
        {hasBadge && active && (
          <div
            className="absolute -top-1 -right-1 w-2 h-2 rounded-full"
            style={{ backgroundColor: '#E67E22' }}
          />
        )}
      </div>
      <div
        className="text-[10px]"
        style={{
          color: active ? '#1A3A5C' : '#999999',
          fontWeight: active ? 700 : 400
        }}
      >
        {label}
      </div>
    </button>
  );
}

export function IncomingTransfersScreen() {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col h-screen w-[390px] mx-auto" style={{ backgroundColor: '#F7F9FC' }}>
      {/* Top Bar */}
      <div
        className="flex items-center justify-between px-5 h-14"
        style={{ backgroundColor: '#1A3A5C' }}
      >
        <div className="w-5" />
        <div className="text-white text-[17px]" style={{ fontWeight: 700 }}>
          PharmaTrace
        </div>
        <div className="relative">
          <Bell size={20} className="text-white" />
          <div
            className="absolute -top-1 -right-1 w-[18px] h-[18px] rounded-full flex items-center justify-center"
            style={{ backgroundColor: '#E67E22' }}
          >
            <span className="text-white text-[10px]" style={{ fontWeight: 700 }}>3</span>
          </div>
        </div>
      </div>

      {/* Welcome Strip */}
      <div
        className="px-5 py-4 border-b flex items-center justify-between"
        style={{ backgroundColor: '#FFFFFF', borderColor: '#DCE6F0' }}
      >
        <div>
          <div className="text-[15px]" style={{ fontWeight: 600, color: '#1A3A5C' }}>
            Pharmacie Centrale
          </div>
          <div className="text-[12px] mt-0.5" style={{ color: '#27AE60' }}>
            Pharmacie agréée
          </div>
        </div>
        <div className="text-[12px]" style={{ color: '#999999' }}>
          23 mai 2026
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {/* Page Title */}
        <div className="px-5 pt-4 flex items-center gap-2.5">
          <div className="text-[22px]" style={{ fontWeight: 700, color: '#1A3A5C' }}>
            Transferts entrants
          </div>
          <div
            className="px-2.5 py-0.5 rounded-full text-[13px]"
            style={{
              backgroundColor: '#FEF4E0',
              color: '#E67E22',
              fontWeight: 700
            }}
          >
            3
          </div>
        </div>

        {/* Orange Alert Strip */}
        <div
          className="mx-5 mt-3 px-4 py-3 rounded-lg border"
          style={{
            backgroundColor: '#FEF4E0',
            borderColor: '#F5D5B0'
          }}
        >
          <div className="text-[13px]" style={{ fontWeight: 600, color: '#E67E22' }}>
            ⚡ 3 lots attendent votre confirmation.
          </div>
        </div>

        {/* Transfer Cards */}
        <div className="px-5 mt-3.5 space-y-3">
          <TransferCard
            medicine="Amoxicilline 500mg"
            quantity={500}
            dosage="500mg"
            from="Laboratoire Niger Pharma"
            timeAgo="Il y a 2j"
            onAccept={() => navigate('/pharmacie/reception')}
          />
          <TransferCard
            medicine="Paracétamol 1000mg"
            quantity={300}
            dosage="1000mg"
            from="Laboratoire Niger Pharma"
            timeAgo="Il y a 1j"
            onAccept={() => navigate('/pharmacie/reception')}
          />
          <TransferCard
            medicine="Artéméther / Luméfantrine 20mg"
            quantity={1000}
            dosage="20mg"
            from="Laboratoire Niger Pharma"
            timeAgo="Aujourd'hui"
            onAccept={() => navigate('/pharmacie/reception')}
          />
        </div>
      </div>

      {/* Bottom Tab Bar */}
      <PharmacyTabBar activeTab="transferts" onTabChange={(tab) => {
        if (tab === 'stock') navigate('/pharmacie/stock');
        if (tab === 'scan') navigate('/scanner');
        if (tab === 'compte') navigate('/pharmacie/compte');
      }} />
    </div>
  );
}

interface TransferCardProps {
  medicine: string;
  quantity: number;
  dosage: string;
  from: string;
  timeAgo: string;
  onAccept: () => void;
}

function TransferCard({ medicine, quantity, dosage, from, timeAgo, onAccept }: TransferCardProps) {
  return (
    <div
      className="p-4 rounded-xl"
      style={{
        backgroundColor: '#FFFFFF',
        boxShadow: '0 2px 12px rgba(0,0,0,0.08)',
        borderLeft: '5px solid #E67E22'
      }}
    >
      {/* Top Row */}
      <div className="flex justify-between items-start">
        <div>
          <div
            className="inline-block px-2.5 py-1 rounded-full text-[11px]"
            style={{
              backgroundColor: '#FEF4E0',
              color: '#E67E22',
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '0.5px'
            }}
          >
            EN ATTENTE
          </div>
          <div className="text-[17px] mt-1.5" style={{ fontWeight: 700, color: '#1A3A5C' }}>
            {medicine}
          </div>
          <div className="text-[13px] mt-0.5" style={{ color: '#666666' }}>
            {quantity} unités • Dosage : {dosage}
          </div>
        </div>
        <div className="text-[12px]" style={{ color: '#BBBBBB' }}>
          {timeAgo}
        </div>
      </div>

      {/* Middle Row */}
      <div
        className="flex items-center gap-1.5 mt-3 pt-3"
        style={{ borderTop: '1px solid #F7F9FC' }}
      >
        <Factory size={14} style={{ color: '#999999' }} />
        <div className="text-[13px]" style={{ color: '#555555' }}>
          De : {from}
        </div>
      </div>

      {/* Bottom Row - Actions */}
      <div
        className="flex gap-2 mt-3 pt-3"
        style={{ borderTop: '1px solid #F7F9FC' }}
      >
        <button
          className="flex-1 h-[42px] rounded-lg text-[14px]"
          style={{
            backgroundColor: '#FFFFFF',
            border: '1px solid #C0392B',
            color: '#C0392B',
            fontWeight: 600
          }}
        >
          Refuser
        </button>
        <button
          onClick={onAccept}
          className="flex-[2] h-[42px] rounded-lg text-[14px] text-white"
          style={{
            backgroundColor: '#27AE60',
            fontWeight: 700
          }}
        >
          ✓ Réceptionner
        </button>
      </div>
    </div>
  );
}
