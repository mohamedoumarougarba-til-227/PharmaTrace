import { MobileLayout } from './MobileLayout';
import { ChevronDown, Check } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router';

export function InitiateTransferScreen() {
  const navigate = useNavigate();
  const [showDropdown, setShowDropdown] = useState(true);
  const [quantity, setQuantity] = useState(500);

  return (
    <MobileLayout
      title="Transfert"
      showBackButton
      onBackClick={() => navigate('/fabricant/qr-genere')}
      activeTab="transferts"
      onTabChange={(tab) => {
        if (tab === 'nouveau') navigate('/fabricant/nouveau-lot');
        if (tab === 'lots') navigate('/fabricant/qr-genere');
        if (tab === 'compte') navigate('/fabricant/compte');
      }}
    >
      {/* Lot Recap Card */}
      <div
        className="mx-5 mt-4 p-4 rounded-xl"
        style={{
          backgroundColor: '#EEF4FB',
          border: '1px solid #DCE6F0'
        }}
      >
        <div
          className="text-[10px]"
          style={{
            color: '#2E6DA4',
            fontWeight: 700,
            textTransform: 'uppercase',
            letterSpacing: '1.5px'
          }}
        >
          LOT À TRANSFÉRER
        </div>
        <div className="text-[18px] mt-1.5" style={{ fontWeight: 700, color: '#1A3A5C' }}>
          Amoxicilline 500mg
        </div>
        <div className="flex gap-2 items-center mt-1.5">
          <span
            className="px-2.5 py-0.5 rounded text-[11px] text-white"
            style={{ backgroundColor: '#1A3A5C' }}
          >
            FAB-2026-049
          </span>
          <span className="text-[13px]" style={{ color: '#27AE60' }}>
            2 000 unités disponibles
          </span>
        </div>
      </div>

      {/* Form Card */}
      <div
        className="mx-5 mt-4 p-5 rounded-xl"
        style={{
          backgroundColor: '#FFFFFF',
          boxShadow: '0 2px 12px rgba(0,0,0,0.08)'
        }}
      >
        {/* Field 1: Pharmacie destinataire */}
        <div className="mb-5">
          <label className="text-[13px] block mb-2" style={{ fontWeight: 700, color: '#1A1A1A' }}>
            Pharmacie destinataire *
          </label>
          <div className="relative">
            <button
              onClick={() => setShowDropdown(!showDropdown)}
              className="w-full h-[52px] px-3.5 rounded-lg flex items-center justify-between text-[15px]"
              style={{
                border: '1px solid #DCE6F0',
                color: '#1A1A1A'
              }}
            >
              <div className="flex items-center gap-2">
                <span>💊</span>
                <span>Pharmacie Centrale de Niamey</span>
              </div>
              <ChevronDown size={18} style={{ color: '#666666' }} />
            </button>

            {/* Dropdown Options */}
            {showDropdown && (
              <div
                className="absolute top-full mt-1 w-full rounded-lg overflow-hidden z-10"
                style={{
                  backgroundColor: '#FFFFFF',
                  border: '1px solid #DCE6F0',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.12)'
                }}
              >
                <DropdownOption
                  emoji="💊"
                  name="Pharmacie Centrale de Niamey"
                  address="Avenue du Fleuve, Niamey"
                  selected
                />
                <DropdownOption
                  emoji="💊"
                  name="Pharmacie du Marché Katako"
                  address="Rue du Commerce, Niamey"
                />
                <DropdownOption
                  emoji="🏥"
                  name="Centre de Santé Yantala"
                  address="Quartier Yantala, Niamey"
                />
              </div>
            )}
          </div>
        </div>

        {/* Field 2: Quantité à transférer */}
        <div className="mb-5">
          <label className="text-[13px] block mb-2" style={{ fontWeight: 700, color: '#1A1A1A' }}>
            Quantité à transférer *
          </label>
          <div className="flex gap-2.5 items-center">
            <button
              onClick={() => setQuantity(Math.max(0, quantity - 10))}
              className="w-12 h-12 rounded-lg flex items-center justify-center text-[20px]"
              style={{
                border: '1px solid #DCE6F0',
                color: '#1A1A1A',
                fontWeight: 700
              }}
            >
              −
            </button>
            <input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(Number(e.target.value))}
              className="flex-1 h-[52px] rounded-lg text-center text-[18px]"
              style={{
                border: '1px solid #DCE6F0',
                color: '#1A1A1A',
                fontWeight: 700
              }}
            />
            <button
              onClick={() => setQuantity(Math.min(2000, quantity + 10))}
              className="w-12 h-12 rounded-lg flex items-center justify-center text-[20px]"
              style={{
                border: '1px solid #DCE6F0',
                color: '#1A1A1A',
                fontWeight: 700
              }}
            >
              +
            </button>
          </div>
          <div className="text-[12px] mt-1.5" style={{ color: '#999999' }}>
            Maximum disponible : 2 000 unités
          </div>
        </div>

        {/* Field 3: Notes */}
        <div className="mb-4">
          <label className="text-[13px] mb-2 block" style={{ fontWeight: 700, color: '#1A1A1A' }}>
            Notes / Bon de livraison{' '}
            <span className="text-[12px]" style={{ color: '#999999', fontWeight: 400 }}>
              (optionnel)
            </span>
          </label>
          <textarea
            placeholder="N° bon de livraison, instructions..."
            className="w-full h-[88px] px-3.5 py-3 rounded-lg text-[14px] resize-none"
            style={{
              border: '1px solid #DCE6F0',
              color: '#1A1A1A'
            }}
          />
        </div>

        {/* Warning Box */}
        <div
          className="p-3 rounded-r-lg"
          style={{
            backgroundColor: '#FEF4E0',
            borderLeft: '4px solid #E67E22'
          }}
        >
          <div className="text-[13px]" style={{ color: '#666666', lineHeight: '1.6' }}>
            ⚠️ Le lot passera en statut En transit. La pharmacie devra confirmer la réception par scan.
          </div>
        </div>
      </div>

      {/* Spacer for sticky button */}
      <div className="h-20" />

      {/* Sticky Bottom Action */}
      <div
        className="fixed bottom-16 left-0 w-[390px] border-t py-3 px-5"
        style={{
          backgroundColor: '#FFFFFF',
          borderColor: '#DCE6F0'
        }}
      >
        <button
          className="w-full h-[52px] rounded-lg text-white text-[16px]"
          style={{
            backgroundColor: '#1A3A5C',
            fontWeight: 700
          }}
        >
          Confirmer le transfert →
        </button>
      </div>
    </MobileLayout>
  );
}

interface DropdownOptionProps {
  emoji: string;
  name: string;
  address: string;
  selected?: boolean;
}

function DropdownOption({ emoji, name, address, selected = false }: DropdownOptionProps) {
  return (
    <button
      className="w-full px-3.5 py-3 flex items-center justify-between"
      style={{
        backgroundColor: selected ? '#EEF4FB' : '#FFFFFF'
      }}
    >
      <div className="flex flex-col items-start gap-0.5">
        <div className="flex items-center gap-2">
          <span>{emoji}</span>
          <span
            className="text-[14px]"
            style={{
              fontWeight: selected ? 700 : 400,
              color: selected ? '#1A3A5C' : '#1A1A1A'
            }}
          >
            {name}
          </span>
        </div>
        <div className="text-[12px] ml-6" style={{ color: '#999999' }}>
          {address}
        </div>
      </div>
      {selected && <Check size={18} style={{ color: '#2E6DA4' }} />}
    </button>
  );
}
