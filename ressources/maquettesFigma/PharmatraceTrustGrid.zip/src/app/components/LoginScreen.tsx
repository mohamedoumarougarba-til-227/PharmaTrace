import { useState } from 'react';
import { useNavigate } from 'react-router';

type Role = 'fabricant' | 'pharmacie';

export function LoginScreen() {
  const navigate = useNavigate();
  const [selectedRole, setSelectedRole] = useState<Role>('fabricant');

  const handleLogin = () => {
    if (selectedRole === 'fabricant') {
      navigate('/fabricant/nouveau-lot');
    } else {
      navigate('/pharmacie/transferts');
    }
  };

  return (
    <div className="w-[390px] h-[844px] flex flex-col" style={{ backgroundColor: '#F7F9FC' }}>
      {/* Top Bar */}
      <div className="h-14 flex items-center justify-center px-5" style={{ backgroundColor: '#1A3A5C' }}>
        <h1 className="text-[17px] text-white" style={{ fontFamily: 'Inter', fontWeight: 700 }}>
          PharmaTrace
        </h1>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col justify-center px-5">
        {/* Logo & Title */}
        <div className="text-center mb-8">
          <div className="text-[64px] mb-4">💊</div>
          <h2 className="text-[28px] mb-2" style={{ fontFamily: 'Inter', fontWeight: 700, color: '#1A3A5C' }}>
            Connexion
          </h2>
          <p className="text-[14px]" style={{ color: '#666666', lineHeight: 1.5 }}>
            Accédez à votre espace professionnel
          </p>
        </div>

        {/* Login Form */}
        <div className="bg-white rounded-xl p-6 mb-4" style={{ boxShadow: '0 2px 12px rgba(0,0,0,0.08)' }}>
          {/* Role Selection */}
          <div className="mb-5">
            <label className="block text-[13px] mb-2" style={{ fontFamily: 'Inter', fontWeight: 700, color: '#1A1A1A' }}>
              Type de compte *
            </label>
            <div className="flex gap-2">
              <button
                onClick={() => setSelectedRole('fabricant')}
                className="flex-1 h-12 rounded-lg flex items-center justify-center gap-2 text-[14px] transition-all"
                style={{
                  borderWidth: selectedRole === 'fabricant' ? '2px' : '1px',
                  borderColor: selectedRole === 'fabricant' ? '#2E6DA4' : '#DCE6F0',
                  backgroundColor: selectedRole === 'fabricant' ? '#EEF4FB' : '#FFFFFF',
                  color: selectedRole === 'fabricant' ? '#1A3A5C' : '#666666',
                  fontFamily: 'Inter',
                  fontWeight: selectedRole === 'fabricant' ? 600 : 400
                }}
              >
                👨‍🔬 Fabricant
              </button>
              <button
                onClick={() => setSelectedRole('pharmacie')}
                className="flex-1 h-12 rounded-lg flex items-center justify-center gap-2 text-[14px] transition-all"
                style={{
                  borderWidth: selectedRole === 'pharmacie' ? '2px' : '1px',
                  borderColor: selectedRole === 'pharmacie' ? '#2E6DA4' : '#DCE6F0',
                  backgroundColor: selectedRole === 'pharmacie' ? '#EEF4FB' : '#FFFFFF',
                  color: selectedRole === 'pharmacie' ? '#1A3A5C' : '#666666',
                  fontFamily: 'Inter',
                  fontWeight: selectedRole === 'pharmacie' ? 600 : 400
                }}
              >
                💊 Pharmacie
              </button>
            </div>
          </div>

          {/* Email */}
          <div className="mb-4">
            <label className="block text-[13px] mb-1.5" style={{ fontFamily: 'Inter', fontWeight: 700, color: '#1A1A1A' }}>
              Email *
            </label>
            <input
              type="email"
              placeholder="votre@email.com"
              className="w-full h-[52px] px-4 rounded-lg text-[15px]"
              style={{
                border: '1px solid #DCE6F0',
                fontFamily: 'Inter',
                color: '#1A1A1A'
              }}
            />
          </div>

          {/* Password */}
          <div className="mb-3">
            <label className="block text-[13px] mb-1.5" style={{ fontFamily: 'Inter', fontWeight: 700, color: '#1A1A1A' }}>
              Mot de passe *
            </label>
            <input
              type="password"
              placeholder="••••••••"
              className="w-full h-[52px] px-4 rounded-lg text-[15px]"
              style={{
                border: '1px solid #DCE6F0',
                fontFamily: 'Inter',
                color: '#1A1A1A'
              }}
            />
          </div>

          {/* Forgot Password */}
          <div className="text-right mb-5">
            <button className="text-[13px]" style={{ color: '#2E6DA4', fontFamily: 'Inter', fontWeight: 600 }}>
              Mot de passe oublié ?
            </button>
          </div>

          {/* Login Button */}
          <button
            onClick={handleLogin}
            className="w-full h-[52px] rounded-lg text-white text-[16px]"
            style={{
              backgroundColor: '#1A3A5C',
              fontFamily: 'Inter',
              fontWeight: 700,
              boxShadow: '0 4px 16px rgba(26,58,92,0.3)'
            }}
          >
            Se connecter →
          </button>
        </div>

        {/* Patient Access */}
        <div className="text-center">
          <div className="flex items-center gap-2.5 mb-3">
            <div className="flex-1 h-px" style={{ backgroundColor: '#DCE6F0' }}></div>
            <span className="text-[12px]" style={{ color: '#999999' }}>
              ou
            </span>
            <div className="flex-1 h-px" style={{ backgroundColor: '#DCE6F0' }}></div>
          </div>

          <button
            onClick={() => navigate('/scanner')}
            className="w-full h-12 rounded-lg text-[15px] flex items-center justify-center gap-2"
            style={{
              border: '1px solid #DCE6F0',
              backgroundColor: '#FFFFFF',
              color: '#2E6DA4',
              fontFamily: 'Inter',
              fontWeight: 600
            }}
          >
            🔍 Scanner un médicament
          </button>
          <p className="text-[11px] mt-2" style={{ color: '#999999' }}>
            Aucun compte requis pour vérifier un médicament
          </p>
        </div>
      </div>

      {/* Footer */}
      <div className="px-5 pb-8 text-center">
        <p className="text-[11px]" style={{ color: '#999999' }}>
          MIABE Hackathon 2026 — Team TrustGrid — Niger
        </p>
      </div>
    </div>
  );
}
