import { ArrowLeft, User, Plus, Grid3x3, ArrowLeftRight, UserCircle } from 'lucide-react';

interface MobileLayoutProps {
  children: React.ReactNode;
  title?: string;
  showBackButton?: boolean;
  onBackClick?: () => void;
  rightIcon?: React.ReactNode;
  activeTab?: 'nouveau' | 'lots' | 'transferts' | 'compte';
  onTabChange?: (tab: 'nouveau' | 'lots' | 'transferts' | 'compte') => void;
  showWelcome?: boolean;
}

export function MobileLayout({
  children,
  title = "PharmaTrace",
  showBackButton = false,
  onBackClick,
  rightIcon,
  activeTab = 'nouveau',
  onTabChange,
  showWelcome = false
}: MobileLayoutProps) {
  return (
    <div className="flex flex-col h-screen w-[390px] mx-auto" style={{
      backgroundColor: '#F7F9FC',
      fontFamily: 'Inter, sans-serif'
    }}>
      {/* Top Bar - 56px */}
      <div
        className="flex items-center justify-between px-5 h-14 shrink-0"
        style={{ backgroundColor: '#1A3A5C' }}
      >
        {showBackButton ? (
          <button onClick={onBackClick} className="text-white">
            <ArrowLeft size={20} />
          </button>
        ) : (
          <div className="w-5" />
        )}

        <div className="text-white text-[17px]" style={{ fontWeight: 700 }}>
          {title}
        </div>

        <div className="text-white">
          {rightIcon || <User size={20} />}
        </div>
      </div>

      {/* Welcome Strip */}
      {showWelcome && (
        <div
          className="px-5 py-4 border-b shrink-0"
          style={{
            backgroundColor: '#FFFFFF',
            borderColor: '#DCE6F0'
          }}
        >
          <div className="text-[15px]" style={{
            fontWeight: 600,
            color: '#1A3A5C'
          }}>
            Bonjour, Labo Niger Pharma 👋
          </div>
          <div className="text-[12px] mt-0.5" style={{ color: '#27AE60' }}>
            Fabricant agréé
          </div>
        </div>
      )}

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto pb-32">
        {children}
      </div>

      {/* Bottom Tab Bar - 64px */}
      <div
        className="fixed bottom-0 w-[390px] h-16 flex items-center justify-around border-t shrink-0"
        style={{
          backgroundColor: '#FFFFFF',
          borderColor: '#DCE6F0',
          boxShadow: '0 -2px 8px rgba(0,0,0,0.06)'
        }}
      >
        <TabButton
          icon={<Plus size={20} />}
          label="Nouveau lot"
          active={activeTab === 'nouveau'}
          onClick={() => onTabChange?.('nouveau')}
        />
        <TabButton
          icon={<Grid3x3 size={20} />}
          label="Mes lots"
          active={activeTab === 'lots'}
          onClick={() => onTabChange?.('lots')}
        />
        <TabButton
          icon={<ArrowLeftRight size={20} />}
          label="Transferts"
          active={activeTab === 'transferts'}
          onClick={() => onTabChange?.('transferts')}
        />
        <TabButton
          icon={<UserCircle size={20} />}
          label="Compte"
          active={activeTab === 'compte'}
          onClick={() => onTabChange?.('compte')}
        />
      </div>
    </div>
  );
}

interface TabButtonProps {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
}

function TabButton({ icon, label, active, onClick }: TabButtonProps) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1">
      <div style={{ color: active ? '#1A3A5C' : '#999999' }}>
        {icon}
      </div>
      <div
        className="text-[10px]"
        style={{
          color: active ? '#1A3A5C' : '#999999',
          fontWeight: active ? 700 : 400
        }}
      >
        {label}
      </div>
    </button>
  );
}
