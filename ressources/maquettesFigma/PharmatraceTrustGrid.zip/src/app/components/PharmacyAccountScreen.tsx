import { ChevronRight, LogOut, Bell } from 'lucide-react';
import { useNavigate } from 'react-router';

interface TabBarProps {
  activeTab: 'transferts' | 'stock' | 'scan' | 'compte';
  onTabChange: (tab: 'transferts' | 'stock' | 'scan' | 'compte') => void;
}

function PharmacyTabBar({ activeTab, onTabChange }: TabBarProps) {
  return (
    <div
      className="fixed bottom-0 w-[390px] h-16 flex items-center justify-around border-t"
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: '#DCE6F0',
        boxShadow: '0 -2px 8px rgba(0,0,0,0.06)'
      }}
    >
      <PharmacyTabButton
        emoji="📥"
        label="Transferts"
        active={activeTab === 'transferts'}
        onClick={() => onTabChange('transferts')}
      />
      <PharmacyTabButton
        emoji="📦"
        label="Stock"
        active={activeTab === 'stock'}
        onClick={() => onTabChange('stock')}
      />
      <PharmacyTabButton
        emoji="🔍"
        label="Scan"
        active={activeTab === 'scan'}
        onClick={() => onTabChange('scan')}
      />
      <PharmacyTabButton
        emoji="👤"
        label="Compte"
        active={activeTab === 'compte'}
        onClick={() => onTabChange('compte')}
      />
    </div>
  );
}

function PharmacyTabButton({ emoji, label, active, onClick }: {
  emoji: string;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button className="flex flex-col items-center gap-1" onClick={onClick}>
      <span className="text-[18px]">{emoji}</span>
      <div
        className="text-[10px]"
        style={{
          color: active ? '#1A3A5C' : '#999999',
          fontWeight: active ? 700 : 400
        }}
      >
        {label}
      </div>
    </button>
  );
}

export function PharmacyAccountScreen() {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col h-screen w-[390px] mx-auto" style={{ backgroundColor: '#F7F9FC' }}>
      {/* Top Bar */}
      <div
        className="flex items-center justify-between px-5 h-14"
        style={{ backgroundColor: '#1A3A5C' }}
      >
        <div className="w-5" />
        <div className="text-white text-[17px]" style={{ fontWeight: 700 }}>
          Mon Compte
        </div>
        <div className="relative">
          <Bell size={20} className="text-white" />
          <div
            className="absolute -top-1 -right-1 w-[18px] h-[18px] rounded-full flex items-center justify-center"
            style={{ backgroundColor: '#E67E22' }}
          >
            <span className="text-white text-[10px]" style={{ fontWeight: 700 }}>3</span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {/* Profile Header */}
        <div
          className="mx-5 mt-4 p-5 rounded-xl text-center"
          style={{
            backgroundColor: '#FFFFFF',
            boxShadow: '0 2px 12px rgba(0,0,0,0.08)'
          }}
        >
          <div
            className="w-20 h-20 mx-auto rounded-full flex items-center justify-center text-[32px]"
            style={{
              backgroundColor: '#EEF4FB',
              border: '3px solid #2E6DA4'
            }}
          >
            💊
          </div>
          <div className="text-[20px] mt-3" style={{ fontWeight: 700, color: '#1A3A5C' }}>
            Pharmacie Centrale
          </div>
          <div
            className="inline-block px-3 py-1 rounded-full text-[12px] mt-2"
            style={{
              backgroundColor: '#E8F8EC',
              color: '#27AE60',
              fontWeight: 700
            }}
          >
            ✓ Pharmacie agréée
          </div>
        </div>

        {/* Account Info */}
        <div
          className="mx-5 mt-4 rounded-xl overflow-hidden"
          style={{
            backgroundColor: '#FFFFFF',
            boxShadow: '0 2px 12px rgba(0,0,0,0.08)'
          }}
        >
          <div
            className="px-5 py-3"
            style={{
              backgroundColor: '#F7F9FC',
              borderBottom: '1px solid #DCE6F0'
            }}
          >
            <div
              className="text-[11px]"
              style={{
                color: '#2E6DA4',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '1.5px'
              }}
            >
              INFORMATIONS
            </div>
          </div>

          <AccountMenuItem icon="📧" label="Email" value="contact@pharmaciecentrale.ne" />
          <AccountMenuItem icon="📱" label="Téléphone" value="+227 20 73 89 12" />
          <AccountMenuItem icon="📍" label="Adresse" value="Avenue du Fleuve, Niamey" />
          <AccountMenuItem icon="🆔" label="N° Agrément" value="PHAR-NE-2024-008" isLast />
        </div>

        {/* Statistics */}
        <div
          className="mx-5 mt-4 rounded-xl overflow-hidden"
          style={{
            backgroundColor: '#FFFFFF',
            boxShadow: '0 2px 12px rgba(0,0,0,0.08)'
          }}
        >
          <div
            className="px-5 py-3"
            style={{
              backgroundColor: '#F7F9FC',
              borderBottom: '1px solid #DCE6F0'
            }}
          >
            <div
              className="text-[11px]"
              style={{
                color: '#2E6DA4',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '1.5px'
              }}
            >
              STATISTIQUES
            </div>
          </div>

          <div className="p-5 grid grid-cols-3 gap-4">
            <StatCard number="27" label="En stock" />
            <StatCard number="45" label="Reçus" />
            <StatCard number="158" label="Vérifications" color="#2E6DA4" />
          </div>
        </div>

        {/* Settings */}
        <div
          className="mx-5 mt-4 rounded-xl overflow-hidden"
          style={{
            backgroundColor: '#FFFFFF',
            boxShadow: '0 2px 12px rgba(0,0,0,0.08)'
          }}
        >
          <SettingsMenuItem icon="🔔" label="Notifications" />
          <SettingsMenuItem icon="🔒" label="Sécurité" />
          <SettingsMenuItem icon="⚙️" label="Paramètres" />
          <SettingsMenuItem icon="❓" label="Aide & Support" isLast />
        </div>

        {/* Logout Button */}
        <div className="mx-5 mt-4 mb-6">
          <button
            onClick={() => navigate('/')}
            className="w-full h-[52px] rounded-lg flex items-center justify-center gap-2 text-[15px]"
            style={{
              backgroundColor: '#FFFFFF',
              border: '2px solid #C0392B',
              color: '#C0392B',
              fontWeight: 700
            }}
          >
            <LogOut size={18} />
            Se déconnecter
          </button>
        </div>
      </div>

      {/* Bottom Tab Bar */}
      <PharmacyTabBar
        activeTab="compte"
        onTabChange={(tab) => {
          if (tab === 'transferts') navigate('/pharmacie/transferts');
          if (tab === 'stock') navigate('/pharmacie/stock');
          if (tab === 'scan') navigate('/scanner');
        }}
      />
    </div>
  );
}

interface AccountMenuItemProps {
  icon: string;
  label: string;
  value: string;
  isLast?: boolean;
}

function AccountMenuItem({ icon, label, value, isLast = false }: AccountMenuItemProps) {
  return (
    <div
      className="px-5 py-3.5 flex items-center gap-3"
      style={{
        borderBottom: isLast ? 'none' : '1px solid #F7F9FC'
      }}
    >
      <span className="text-[20px]">{icon}</span>
      <div className="flex-1">
        <div className="text-[12px]" style={{ color: '#999999' }}>
          {label}
        </div>
        <div className="text-[14px] mt-0.5" style={{ color: '#1A1A1A', fontWeight: 600 }}>
          {value}
        </div>
      </div>
    </div>
  );
}

interface StatCardProps {
  number: string;
  label: string;
  color?: string;
}

function StatCard({ number, label, color = '#1A3A5C' }: StatCardProps) {
  return (
    <div className="text-center">
      <div className="text-[24px]" style={{ fontWeight: 900, color }}>
        {number}
      </div>
      <div className="text-[10px] mt-1" style={{ color: '#666666' }}>
        {label}
      </div>
    </div>
  );
}

interface SettingsMenuItemProps {
  icon: string;
  label: string;
  isLast?: boolean;
}

function SettingsMenuItem({ icon, label, isLast = false }: SettingsMenuItemProps) {
  return (
    <button
      className="w-full px-5 py-4 flex items-center justify-between"
      style={{
        borderBottom: isLast ? 'none' : '1px solid #F7F9FC'
      }}
    >
      <div className="flex items-center gap-3">
        <span className="text-[18px]">{icon}</span>
        <span className="text-[15px]" style={{ color: '#1A1A1A', fontWeight: 600 }}>
          {label}
        </span>
      </div>
      <ChevronRight size={18} style={{ color: '#CCCCCC' }} />
    </button>
  );
}
