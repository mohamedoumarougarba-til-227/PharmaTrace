import { MobileLayout } from './MobileLayout';
import { Share2, Download, Printer } from 'lucide-react';
import { useNavigate } from 'react-router';

export function QRCodeGeneratedScreen() {
  const navigate = useNavigate();
  return (
    <MobileLayout
      title="PharmaTrace"
      showBackButton
      onBackClick={() => navigate('/fabricant/nouveau-lot')}
      rightIcon={<Share2 size={20} />}
      activeTab="lots"
      onTabChange={(tab) => {
        if (tab === 'nouveau') navigate('/fabricant/nouveau-lot');
        if (tab === 'transferts') navigate('/fabricant/transfert');
        if (tab === 'compte') navigate('/fabricant/compte');
      }}
    >
      {/* Success Banner */}
      <div className="px-5 py-3.5" style={{ backgroundColor: '#27AE60' }}>
        <div className="text-[15px] text-white" style={{ fontWeight: 700 }}>
          ✓ Lot enregistré avec succès !
        </div>
        <div className="text-[13px] mt-0.5" style={{ color: 'rgba(255,255,255,0.8)' }}>
          FAB-2026-049 — Amoxicilline 500mg
        </div>
      </div>

      {/* QR Card */}
      <div
        className="mx-5 mt-4 p-7 rounded-2xl flex flex-col items-center"
        style={{
          backgroundColor: '#FFFFFF',
          boxShadow: '0 2px 12px rgba(0,0,0,0.08)'
        }}
      >
        <div
          className="text-[11px] text-center"
          style={{
            color: '#2E6DA4',
            fontWeight: 700,
            textTransform: 'uppercase',
            letterSpacing: '1.5px'
          }}
        >
          QR CODE DE TRAÇABILITÉ
        </div>

        {/* QR Code Image */}
        <div className="mt-4" style={{
          width: '240px',
          height: '240px',
          border: '1px solid #DCE6F0',
          borderRadius: '8px',
          backgroundColor: '#FFFFFF',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          <svg width="220" height="220" viewBox="0 0 220 220">
            {/* QR Code pattern - simplified representation */}
            <rect x="0" y="0" width="220" height="220" fill="white"/>
            {/* Corner markers */}
            <rect x="10" y="10" width="50" height="50" fill="black"/>
            <rect x="20" y="20" width="30" height="30" fill="white"/>
            <rect x="25" y="25" width="20" height="20" fill="black"/>

            <rect x="160" y="10" width="50" height="50" fill="black"/>
            <rect x="170" y="20" width="30" height="30" fill="white"/>
            <rect x="175" y="25" width="20" height="20" fill="black"/>

            <rect x="10" y="160" width="50" height="50" fill="black"/>
            <rect x="20" y="170" width="30" height="30" fill="white"/>
            <rect x="25" y="175" width="20" height="20" fill="black"/>

            {/* Data pattern (simplified) */}
            {Array.from({ length: 15 }).map((_, i) =>
              Array.from({ length: 15 }).map((_, j) => (
                (i + j) % 3 === 0 ? (
                  <rect
                    key={`${i}-${j}`}
                    x={80 + j * 8}
                    y={80 + i * 8}
                    width="6"
                    height="6"
                    fill="black"
                  />
                ) : null
              ))
            )}
          </svg>
        </div>

        <div className="text-[15px] text-center mt-3.5" style={{ fontWeight: 700, color: '#1A3A5C' }}>
          FAB-2026-049
        </div>
        <div className="text-[13px] text-center mt-1" style={{ color: '#666666' }}>
          Amoxicilline 500mg
        </div>

        {/* Button Row */}
        <div className="w-full mt-5 space-y-2">
          <button
            className="w-full h-12 rounded-lg flex items-center justify-center gap-2 text-[14px]"
            style={{
              backgroundColor: '#FFFFFF',
              border: '1px solid #DCE6F0',
              color: '#1A3A5C',
              fontWeight: 600
            }}
          >
            <Download size={18} />
            Télécharger
          </button>
          <button
            className="w-full h-12 rounded-lg flex items-center justify-center gap-2 text-[14px]"
            style={{
              backgroundColor: '#FFFFFF',
              border: '1px solid #DCE6F0',
              color: '#1A3A5C',
              fontWeight: 600
            }}
          >
            <Printer size={18} />
            Imprimer
          </button>
        </div>
      </div>

      {/* Info Card */}
      <div
        className="mx-5 mt-4 p-5 rounded-xl"
        style={{
          backgroundColor: '#FFFFFF',
          boxShadow: '0 2px 12px rgba(0,0,0,0.08)'
        }}
      >
        <div
          className="text-[15px] pb-3 mb-4"
          style={{
            fontWeight: 600,
            color: '#1A3A5C',
            borderBottom: '1px solid #DCE6F0'
          }}
        >
          Détails du lot
        </div>

        <InfoRow label="Médicament" value="Amoxicilline 500mg" valueBold />
        <InfoRow label="N° de lot" value="FAB-2026-049" valueColor="#2E6DA4" valueBold />
        <InfoRow label="Quantité" value="2 000 unités" />
        <InfoRow label="Fabrication" value="15/05/2026" />
        <InfoRow label="Expiration" value="15/05/2028" valueColor="#27AE60" valueBold />
        <InfoRow
          label="Statut"
          value={
            <span
              className="px-2.5 py-1 rounded-full text-[11px]"
              style={{
                backgroundColor: '#27AE60',
                color: '#FFFFFF',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '1px'
              }}
            >
              En stock ✓
            </span>
          }
          isLast
        />
      </div>

      {/* Hash Block */}
      <div
        className="mx-5 mt-3 p-4 rounded-lg"
        style={{ backgroundColor: '#1A3A5C' }}
      >
        <div
          className="text-[10px]"
          style={{
            color: 'rgba(255,255,255,0.6)',
            textTransform: 'uppercase',
            letterSpacing: '1.5px'
          }}
        >
          🔐 EMPREINTE SHA-256
        </div>
        <div
          className="text-[13px] mt-1.5 break-all"
          style={{
            color: 'rgba(255,255,255,0.9)',
            fontWeight: 700,
            fontFamily: 'monospace'
          }}
        >
          a3f8b2c9d4e61f07...
        </div>
        <div
          className="text-[11px] mt-1.5 italic"
          style={{ color: 'rgba(255,255,255,0.5)' }}
        >
          Immuable — ne peut jamais être falsifiée
        </div>
      </div>

      {/* Spacer for sticky button */}
      <div className="h-20" />

      {/* Sticky Bottom Action */}
      <div
        className="fixed bottom-16 left-0 w-[390px] border-t py-3 px-5"
        style={{
          backgroundColor: '#FFFFFF',
          borderColor: '#DCE6F0'
        }}
      >
        <button
          onClick={() => navigate('/fabricant/transfert')}
          className="w-full h-[52px] rounded-lg text-white text-[16px]"
          style={{
            backgroundColor: '#1A3A5C',
            fontWeight: 700
          }}
        >
          Initier un transfert →
        </button>
      </div>
    </MobileLayout>
  );
}

interface InfoRowProps {
  label: string;
  value: React.ReactNode;
  valueColor?: string;
  valueBold?: boolean;
  isLast?: boolean;
}

function InfoRow({ label, value, valueColor = '#1A1A1A', valueBold = false, isLast = false }: InfoRowProps) {
  return (
    <div
      className="flex justify-between items-center h-10"
      style={{
        borderBottom: isLast ? 'none' : '1px solid #F7F9FC'
      }}
    >
      <span className="text-[14px]" style={{ color: '#666666' }}>
        {label}
      </span>
      <span
        className="text-[14px]"
        style={{
          color: valueColor,
          fontWeight: valueBold ? 700 : 400
        }}
      >
        {value}
      </span>
    </div>
  );
}
