import { ArrowLeft, Camera } from 'lucide-react';
import { useNavigate } from 'react-router';

export function ReceiveBatchScreen() {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col h-screen w-[390px] mx-auto" style={{ backgroundColor: '#F7F9FC' }}>
      {/* Top Bar */}
      <div
        className="flex items-center justify-between px-5 h-14"
        style={{ backgroundColor: '#1A3A5C' }}
      >
        <button onClick={() => navigate('/pharmacie/transferts')} className="text-white">
          <ArrowLeft size={20} />
        </button>
        <div className="text-white text-[17px]" style={{ fontWeight: 700 }}>
          Réception du lot
        </div>
        <div className="w-5" />
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-32">
        {/* Lot Info Card */}
        <div
          className="mx-5 mt-4 px-4 py-4 rounded-xl border"
          style={{
            backgroundColor: '#EEF4FB',
            borderColor: '#DCE6F0'
          }}
        >
          <div
            className="text-[10px]"
            style={{
              color: '#2E6DA4',
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '1.5px'
            }}
          >
            LOT À RÉCEPTIONNER
          </div>
          <div className="text-[17px] mt-1.5" style={{ fontWeight: 700, color: '#1A3A5C' }}>
            Amoxicilline 500mg
          </div>
          <div className="flex items-center gap-2 mt-1.5">
            <span
              className="px-2.5 py-0.5 rounded text-[11px] text-white"
              style={{ backgroundColor: '#1A3A5C' }}
            >
              FAB-2026-049
            </span>
            <span className="text-[13px]" style={{ color: '#666666' }}>
              500 unités
            </span>
          </div>
        </div>

        {/* Step Indicator */}
        <div className="flex items-center px-5 mt-5">
          {/* Step 1 - Active */}
          <div className="flex items-center">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center"
              style={{ backgroundColor: '#1A3A5C' }}
            >
              <span className="text-white text-[14px]" style={{ fontWeight: 700 }}>1</span>
            </div>
            <span className="text-[13px] ml-2" style={{ fontWeight: 700, color: '#1A3A5C' }}>
              Scanner le lot
            </span>
          </div>

          {/* Line */}
          <div
            className="flex-1 mx-3 h-0.5"
            style={{
              borderTop: '2px dashed #DCE6F0'
            }}
          />

          {/* Step 2 - Inactive */}
          <div className="flex items-center">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center"
              style={{
                border: '2px solid #DCE6F0',
                backgroundColor: 'transparent'
              }}
            >
              <span className="text-[14px]" style={{ color: '#BBBBBB' }}>2</span>
            </div>
            <span className="text-[13px] ml-2" style={{ color: '#BBBBBB' }}>
              Confirmer
            </span>
          </div>
        </div>

        {/* Scanner Zone */}
        <div
          className="mx-5 mt-4 rounded-2xl flex flex-col items-center justify-center px-5"
          style={{
            border: '2px dashed #2E6DA4',
            backgroundColor: '#FFFFFF',
            height: '200px'
          }}
        >
          <Camera size={40} style={{ color: '#2E6DA4' }} />
          <div className="text-[16px] mt-3" style={{ fontWeight: 500, color: '#2E6DA4' }}>
            Activer la caméra
          </div>
          <div className="text-[13px] mt-1.5 text-center" style={{ color: '#999999' }}>
            Pointez vers le QR code du lot reçu
          </div>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-2.5 px-5 mt-5">
          <div className="flex-1 h-px" style={{ backgroundColor: '#DCE6F0' }} />
          <span className="text-[12px]" style={{ color: '#BBBBBB' }}>
            ou saisir manuellement
          </span>
          <div className="flex-1 h-px" style={{ backgroundColor: '#DCE6F0' }} />
        </div>

        {/* Input Row */}
        <div className="px-5 mt-3.5 flex gap-2">
          <input
            type="text"
            placeholder="N° du lot..."
            className="flex-1 h-[52px] px-3.5 rounded-lg text-[14px]"
            style={{
              border: '1px solid #DCE6F0',
              color: '#1A1A1A'
            }}
          />
          <button
            className="w-[52px] h-[52px] rounded-lg text-white text-[14px]"
            style={{
              backgroundColor: '#2E6DA4',
              fontWeight: 700
            }}
          >
            OK
          </button>
        </div>

        {/* Notes Field */}
        <div className="px-5 mt-4">
          <label className="text-[13px] block mb-1.5" style={{ fontWeight: 700, color: '#1A1A1A' }}>
            Notes (optionnel)
          </label>
          <textarea
            placeholder="Ex: colis intact, température correcte..."
            className="w-full h-20 px-3.5 py-2.5 rounded-lg text-[14px] resize-none"
            style={{
              border: '1px solid #DCE6F0',
              color: '#1A1A1A'
            }}
          />
        </div>

        <div className="h-20" />
      </div>

      {/* Sticky Bottom Action */}
      <div
        className="fixed bottom-0 left-0 w-[390px] border-t py-3 px-5 pb-7"
        style={{
          backgroundColor: '#FFFFFF',
          borderColor: '#DCE6F0'
        }}
      >
        <button
          className="w-full h-[52px] rounded-lg text-white text-[16px]"
          style={{
            backgroundColor: '#27AE60',
            fontWeight: 700,
            boxShadow: '0 4px 16px rgba(39,174,96,0.3)'
          }}
        >
          ✓ Confirmer la réception
        </button>
      </div>
    </div>
  );
}
