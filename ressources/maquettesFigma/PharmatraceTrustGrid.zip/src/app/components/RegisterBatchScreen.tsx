import { MobileLayout } from './MobileLayout';
import { Calendar } from 'lucide-react';
import { useNavigate } from 'react-router';

export function RegisterBatchScreen() {
  const navigate = useNavigate();
  return (
    <MobileLayout
      showWelcome
      activeTab="nouveau"
      onTabChange={(tab) => {
        if (tab === 'lots') navigate('/fabricant/qr-genere');
        if (tab === 'transferts') navigate('/fabricant/transfert');
        if (tab === 'compte') navigate('/fabricant/compte');
      }}
    >
      {/* Page Title Block */}
      <div className="px-5 pt-5">
        <div className="text-[24px]" style={{ fontWeight: 700, color: '#1A3A5C' }}>
          Enregistrer un lot
        </div>
        <div className="text-[14px] mt-1" style={{ color: '#666666' }}>
          Créez un nouveau lot de médicaments.
        </div>
      </div>

      {/* Form Card */}
      <div
        className="mx-5 mt-4 p-5 rounded-xl"
        style={{
          backgroundColor: '#FFFFFF',
          boxShadow: '0 2px 12px rgba(0,0,0,0.08)'
        }}
      >
        {/* Section: MÉDICAMENT */}
        <div
          className="text-[11px] mb-3.5"
          style={{
            color: '#2E6DA4',
            fontWeight: 700,
            textTransform: 'uppercase',
            letterSpacing: '1.5px'
          }}
        >
          MÉDICAMENT
        </div>

        {/* Field 1: Nom commercial */}
        <div className="mb-3.5">
          <label className="text-[13px] block mb-1.5" style={{ fontWeight: 700, color: '#1A1A1A' }}>
            Nom commercial *
          </label>
          <input
            type="text"
            defaultValue="Amoxicilline 500mg"
            className="w-full h-[52px] px-4 rounded-lg text-[15px]"
            style={{
              border: '2px solid #2E6DA4',
              color: '#1A1A1A'
            }}
          />
        </div>

        {/* Field 2: Forme galénique */}
        <div className="mb-3.5">
          <label className="text-[13px] block mb-1.5" style={{ fontWeight: 700, color: '#1A1A1A' }}>
            Forme galénique
          </label>
          <select
            className="w-full h-[52px] px-4 rounded-lg text-[15px]"
            style={{
              border: '1px solid #DCE6F0',
              color: '#1A1A1A'
            }}
          >
            <option>Comprimé</option>
          </select>
        </div>

        {/* Field 3: Dosage */}
        <div className="mb-3.5">
          <label className="text-[13px] block mb-1.5" style={{ fontWeight: 700, color: '#1A1A1A' }}>
            Dosage
          </label>
          <input
            type="text"
            defaultValue="500 mg"
            className="w-full h-[52px] px-4 rounded-lg text-[15px]"
            style={{
              border: '1px solid #DCE6F0',
              color: '#1A1A1A'
            }}
          />
          <div className="text-[11px] mt-1.5" style={{ color: '#999999' }}>
            Ex : 500mg, 250mg/5ml
          </div>
        </div>

        {/* Field 4: Quantité */}
        <div className="mb-5">
          <label className="text-[13px] block mb-1.5" style={{ fontWeight: 700, color: '#1A1A1A' }}>
            Quantité d'unités *
          </label>
          <input
            type="number"
            defaultValue="2000"
            className="w-full h-[52px] px-4 rounded-lg text-[15px]"
            style={{
              border: '1px solid #DCE6F0',
              color: '#1A1A1A'
            }}
          />
        </div>

        {/* Divider */}
        <div className="my-5" style={{ borderTop: '1px solid #DCE6F0' }} />

        {/* Section: IDENTIFICATION DU LOT */}
        <div
          className="text-[11px] mb-3.5"
          style={{
            color: '#2E6DA4',
            fontWeight: 700,
            textTransform: 'uppercase',
            letterSpacing: '1.5px'
          }}
        >
          IDENTIFICATION DU LOT
        </div>

        {/* Field 5: Numéro de lot */}
        <div className="mb-3.5">
          <label className="text-[13px] block mb-1.5" style={{ fontWeight: 700, color: '#1A1A1A' }}>
            Numéro de lot officiel *
          </label>
          <input
            type="text"
            defaultValue="FAB-2026-049"
            className="w-full h-[52px] px-4 rounded-lg text-[15px]"
            style={{
              border: '1px solid #DCE6F0',
              color: '#1A1A1A'
            }}
          />
          <div className="text-[11px] mt-1.5" style={{ color: '#999999' }}>
            Doit être unique dans le système
          </div>
        </div>

        {/* Field 6: Date de fabrication */}
        <div className="mb-3.5">
          <label className="text-[13px] block mb-1.5" style={{ fontWeight: 700, color: '#1A1A1A' }}>
            Date de fabrication *
          </label>
          <div className="relative">
            <input
              type="text"
              defaultValue="15 / 05 / 2026"
              className="w-full h-[52px] px-4 pr-12 rounded-lg text-[15px]"
              style={{
                border: '1px solid #DCE6F0',
                color: '#1A1A1A'
              }}
            />
            <Calendar
              size={20}
              className="absolute right-4 top-1/2 -translate-y-1/2"
              style={{ color: '#999999' }}
            />
          </div>
        </div>

        {/* Field 7: Date d'expiration */}
        <div>
          <label className="text-[13px] block mb-1.5" style={{ fontWeight: 700, color: '#1A1A1A' }}>
            Date d'expiration *
          </label>
          <div className="relative">
            <input
              type="text"
              defaultValue="15 / 05 / 2028"
              className="w-full h-[52px] px-4 pr-12 rounded-lg text-[15px]"
              style={{
                border: '2px solid #27AE60',
                color: '#1A1A1A'
              }}
            />
            <Calendar
              size={20}
              className="absolute right-4 top-1/2 -translate-y-1/2"
              style={{ color: '#27AE60' }}
            />
          </div>
          <div className="text-[11px] mt-1.5" style={{ color: '#27AE60' }}>
            ✓ Valide — 2 ans
          </div>
        </div>
      </div>

      {/* Spacer for sticky button */}
      <div className="h-20" />

      {/* Sticky Bottom Action */}
      <div
        className="fixed bottom-16 left-0 w-[390px] border-t py-3 px-5"
        style={{
          backgroundColor: '#FFFFFF',
          borderColor: '#DCE6F0'
        }}
      >
        <button
          onClick={() => navigate('/fabricant/qr-genere')}
          className="w-full h-[52px] rounded-lg text-white text-[16px]"
          style={{
            backgroundColor: '#1A3A5C',
            fontWeight: 700,
            boxShadow: '0 4px 16px rgba(26,58,92,0.3)'
          }}
        >
          Générer le QR code →
        </button>
      </div>
    </MobileLayout>
  );
}
