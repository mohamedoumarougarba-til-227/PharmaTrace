import { Outlet } from 'react-router';

export function RootLayout() {
  return (
    <div className="size-full flex items-center justify-center" style={{ backgroundColor: '#F7F9FC' }}>
      <Outlet />
    </div>
  );
}
