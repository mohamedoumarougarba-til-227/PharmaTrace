import { useNavigate } from 'react-router';

export function ScanMedicineScreen() {
  const navigate = useNavigate();
  return (
    <div className="w-[390px] h-[844px] flex flex-col" style={{ backgroundColor: '#0A0F1A' }}>
      {/* Status Bar */}
      <div className="h-11 flex items-center justify-between px-5" style={{ color: 'white' }}>
        <span className="text-[15px]" style={{ fontFamily: 'Inter', fontWeight: 700 }}>9:41</span>
        <div className="flex items-center gap-1.5">
          <span className="text-[13px]">📶</span>
          <span className="text-[13px]">📶</span>
          <span className="text-[13px]">🔋</span>
        </div>
      </div>

      {/* Top Bar */}
      <div className="h-14 flex items-center justify-between px-5">
        <div></div>
        <h1 className="text-[17px] text-white" style={{ fontFamily: 'Inter', fontWeight: 700 }}>
          PharmaTrace
        </h1>
        <button onClick={() => navigate('/')} className="text-[13px]" style={{ color: '#2E6DA4' }}>
          Se connecter
        </button>
      </div>

      {/* Hero Text */}
      <div className="px-7 mt-8 text-center">
        <h2 className="text-[26px] text-white" style={{ fontFamily: 'Inter', fontWeight: 700, lineHeight: 1.3 }}>
          Vérifiez votre médicament
        </h2>
        <p className="text-[14px] text-white mt-2.5" style={{ opacity: 0.55 }}>
          Scannez le QR code sur l'emballage
        </p>
      </div>

      {/* Viewfinder */}
      <div className="flex flex-col items-center mt-7">
        <div className="relative w-[290px] h-[290px] rounded-lg" style={{ backgroundColor: '#111' }}>
          {/* Corner brackets */}
          <div className="absolute top-0 left-0 w-8 h-8 border-l-[3px] border-t-[3px] border-white"></div>
          <div className="absolute top-0 right-0 w-8 h-8 border-r-[3px] border-t-[3px] border-white"></div>
          <div className="absolute bottom-0 left-0 w-8 h-8 border-l-[3px] border-b-[3px] border-white"></div>
          <div className="absolute bottom-0 right-0 w-8 h-8 border-r-[3px] border-b-[3px] border-white"></div>

          {/* Scan line */}
          <div className="absolute top-1/2 left-0 right-0 h-0.5" style={{ backgroundColor: '#C0392B', transform: 'translateY(-50%)' }}></div>
        </div>

        <div className="flex items-center gap-2 mt-3.5">
          <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: '#2E6DA4' }}></div>
          <span className="text-[12px] text-white italic" style={{ opacity: 0.45 }}>
            Recherche du QR code...
          </span>
        </div>
      </div>

      {/* Manual Section */}
      <div className="px-6 mt-11">
        <div className="flex items-center gap-2.5">
          <div className="flex-1 h-px" style={{ backgroundColor: 'rgba(255,255,255,0.12)' }}></div>
          <span className="text-[12px] text-white" style={{ opacity: 0.3 }}>
            ou saisir l'identifiant
          </span>
          <div className="flex-1 h-px" style={{ backgroundColor: 'rgba(255,255,255,0.12)' }}></div>
        </div>

        <div className="relative mt-3.5">
          <input
            type="text"
            placeholder="Ex : FAB-2026-049"
            className="w-full h-[52px] px-4 rounded-lg text-[14px] text-white placeholder:text-white"
            style={{
              backgroundColor: 'rgba(255,255,255,0.07)',
              border: '1px solid rgba(255,255,255,0.12)',
              opacity: 0.35
            }}
          />
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-white" style={{ opacity: 0.25 }}>📊</span>
        </div>

        <button
          onClick={() => navigate('/resultat/authentique')}
          className="w-full h-[52px] mt-2.5 rounded-lg text-white text-[15px]"
          style={{
            backgroundColor: '#2E6DA4',
            fontFamily: 'Inter',
            fontWeight: 700,
            boxShadow: '0 4px 20px rgba(46,109,164,0.45)'
          }}
        >
          Vérifier →
        </button>
      </div>

      {/* Bottom Note */}
      <div className="text-center mt-8">
        <p className="text-[11px] text-white" style={{ opacity: 0.25 }}>
          Android & iOS — aucune application à installer
        </p>
      </div>

      {/* Home Indicator */}
      <div className="flex justify-center mt-auto pb-2">
        <div className="w-[130px] h-1 rounded-sm" style={{ backgroundColor: 'rgba(255,255,255,0.15)' }}></div>
      </div>
    </div>
  );
}
