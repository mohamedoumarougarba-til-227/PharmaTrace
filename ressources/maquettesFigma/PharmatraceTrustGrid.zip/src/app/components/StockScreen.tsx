import { Search } from 'lucide-react';
import { useNavigate } from 'react-router';

interface TabBarProps {
  activeTab: 'transferts' | 'stock' | 'scan' | 'compte';
  onTabChange: (tab: 'transferts' | 'stock' | 'scan' | 'compte') => void;
}

function PharmacyTabBar({ activeTab, onTabChange }: TabBarProps) {
  return (
    <div
      className="fixed bottom-0 w-[390px] h-16 flex items-center justify-around border-t"
      style={{
        backgroundColor: '#FFFFFF',
        borderColor: '#DCE6F0',
        boxShadow: '0 -2px 8px rgba(0,0,0,0.06)'
      }}
    >
      <PharmacyTabButton
        emoji="📥"
        label="Transferts"
        active={activeTab === 'transferts'}
        onClick={() => onTabChange('transferts')}
      />
      <PharmacyTabButton
        emoji="📦"
        label="Stock"
        active={activeTab === 'stock'}
        onClick={() => onTabChange('stock')}
      />
      <PharmacyTabButton
        emoji="🔍"
        label="Scan"
        active={activeTab === 'scan'}
        onClick={() => onTabChange('scan')}
      />
      <PharmacyTabButton
        emoji="👤"
        label="Compte"
        active={activeTab === 'compte'}
        onClick={() => onTabChange('compte')}
      />
    </div>
  );
}

function PharmacyTabButton({ emoji, label, active, onClick }: {
  emoji: string;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button className="flex flex-col items-center gap-1" onClick={onClick}>
      <span className="text-[18px]">{emoji}</span>
      <div
        className="text-[10px]"
        style={{
          color: active ? '#1A3A5C' : '#999999',
          fontWeight: active ? 700 : 400
        }}
      >
        {label}
      </div>
    </button>
  );
}

export function StockScreen() {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col h-screen w-[390px] mx-auto" style={{ backgroundColor: '#F7F9FC' }}>
      {/* Top Bar */}
      <div
        className="flex items-center justify-between px-5 h-14"
        style={{ backgroundColor: '#1A3A5C' }}
      >
        <div className="w-5" />
        <div className="text-white text-[17px]" style={{ fontWeight: 700 }}>
          Mon Stock
        </div>
        <Search size={20} className="text-white" />
      </div>

      {/* Stock Summary Row */}
      <div
        className="px-5 py-4 border-b flex items-center justify-between"
        style={{
          backgroundColor: '#FFFFFF',
          borderColor: '#DCE6F0'
        }}
      >
        <div className="flex-1 text-center">
          <div className="text-[24px]" style={{ fontWeight: 900, color: '#1A3A5C' }}>
            27
          </div>
          <div className="text-[11px]" style={{ color: '#666666' }}>
            En stock
          </div>
        </div>
        <div className="w-px h-10" style={{ backgroundColor: '#DCE6F0' }} />
        <div className="flex-1 text-center">
          <div className="text-[24px]" style={{ fontWeight: 900, color: '#E67E22' }}>
            2
          </div>
          <div className="text-[11px]" style={{ color: '#666666' }}>
            Exp. bientôt
          </div>
        </div>
        <div className="w-px h-10" style={{ backgroundColor: '#DCE6F0' }} />
        <div className="flex-1 text-center">
          <div className="text-[24px]" style={{ fontWeight: 900, color: '#27AE60' }}>
            0
          </div>
          <div className="text-[11px]" style={{ color: '#666666' }}>
            Alertes
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {/* Warning Strip */}
        <div
          className="mx-5 mt-3.5 px-3.5 py-3"
          style={{
            backgroundColor: '#FEF4E0',
            borderLeft: '4px solid #E67E22',
            borderRadius: '0 8px 8px 0'
          }}
        >
          <div className="text-[13px]" style={{ fontWeight: 600, color: '#E67E22' }}>
            ⚠️ 2 médicaments expirent dans moins de 30 jours.
          </div>
        </div>

        {/* Stock Cards */}
        <div className="px-5 mt-3.5 space-y-2.5">
          <StockCard
            medicine="Amoxicilline 500mg"
            batchNumber="FAB-2026-049"
            dosage="500mg"
            form="Comprimé"
            quantity={500}
            expiration="15/01/2028"
            status="stock"
          />

          <StockCard
            medicine="Paracétamol 1000mg"
            batchNumber="FAB-2026-048"
            dosage="1000mg"
            form="Comprimé"
            quantity={300}
            expiration="20/03/2028"
            status="stock"
          />

          <StockCard
            medicine="Cotrimoxazole 480mg"
            batchNumber="FAB-2026-030"
            dosage="480mg"
            form="Comprimé"
            quantity={45}
            expiration="15/06/2026"
            status="expiring"
          />

          <StockCard
            medicine="Aspirine 500mg"
            batchNumber="FAB-2025-010"
            dosage="500mg"
            form="Comprimé"
            quantity={0}
            expiration="01/01/2025 (périmé)"
            status="archived"
          />
        </div>
      </div>

      {/* Bottom Tab Bar */}
      <PharmacyTabBar activeTab="stock" onTabChange={(tab) => {
        if (tab === 'transferts') navigate('/pharmacie/transferts');
        if (tab === 'scan') navigate('/scanner');
        if (tab === 'compte') navigate('/pharmacie/compte');
      }} />
    </div>
  );
}

interface StockCardProps {
  medicine: string;
  batchNumber: string;
  dosage: string;
  form: string;
  quantity: number;
  expiration: string;
  status: 'stock' | 'expiring' | 'archived';
}

function StockCard({ medicine, batchNumber, dosage, form, quantity, expiration, status }: StockCardProps) {
  const borderColor = status === 'stock' ? '#27AE60' : status === 'expiring' ? '#E67E22' : '#CCCCCC';
  const bgColor = status === 'expiring' ? '#FFFBF5' : '#FFFFFF';
  const opacity = status === 'archived' ? '0.45' : '1';

  return (
    <div
      className="p-4 rounded-xl"
      style={{
        backgroundColor: bgColor,
        boxShadow: '0 2px 12px rgba(0,0,0,0.08)',
        borderLeft: `4px solid ${borderColor}`,
        opacity
      }}
    >
      {/* Top Row */}
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <div className="text-[16px]" style={{ fontWeight: 700, color: '#1A3A5C' }}>
            {medicine}
          </div>
          <div className="text-[12px] mt-1" style={{ color: '#666666' }}>
            N° {batchNumber} • {dosage} • {form}
          </div>
        </div>
        <div>
          {status === 'stock' && (
            <span
              className="px-2.5 py-1 rounded-full text-[11px]"
              style={{
                backgroundColor: '#E8F8EC',
                color: '#27AE60',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '0.5px'
              }}
            >
              En stock
            </span>
          )}
          {status === 'expiring' && (
            <span
              className="px-2.5 py-1 rounded-full text-[11px]"
              style={{
                backgroundColor: '#FEF4E0',
                color: '#E67E22',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '0.5px'
              }}
            >
              Expire bientôt ⚠
            </span>
          )}
          {status === 'archived' && (
            <span
              className="px-2.5 py-1 rounded-full text-[11px]"
              style={{
                backgroundColor: '#F0F0F0',
                color: '#999999',
                fontWeight: 700,
                textTransform: 'uppercase',
                letterSpacing: '0.5px'
              }}
            >
              Archivé
            </span>
          )}
        </div>
      </div>

      {/* Bottom Row */}
      <div
        className="flex justify-between items-center mt-3 pt-3"
        style={{ borderTop: '1px solid #F7F9FC' }}
      >
        <div className="text-[13px]" style={{ color: '#555555' }}>
          {quantity} unités {status === 'archived' && ''}restantes
        </div>
        <div
          className="text-[12px]"
          style={{
            color: status === 'expiring' ? '#E67E22' : '#999999',
            fontWeight: status === 'expiring' ? 700 : 400
          }}
        >
          Exp : {expiration}
        </div>
      </div>

      {/* Actions for expiring items */}
      {status === 'expiring' && (
        <div className="flex gap-2 mt-3">
          <button
            className="flex-1 h-[38px] rounded-lg text-[14px]"
            style={{
              backgroundColor: '#FFFFFF',
              border: '1px solid #DCE6F0',
              color: '#666666'
            }}
          >
            Archiver
          </button>
          <button
            className="flex-1 h-[38px] rounded-lg text-[14px]"
            style={{
              backgroundColor: '#EEF4FB',
              color: '#2E6DA4',
              fontWeight: 700
            }}
          >
            🔍 Vérifier
          </button>
        </div>
      )}
    </div>
  );
}
