import { useNavigate } from 'react-router';

export function SuspectResultScreen() {
  const navigate = useNavigate();
  return (
    <div className="w-[390px] h-[844px] flex flex-col" style={{ backgroundColor: '#C0392B' }}>
      {/* Status Bar */}
      <div className="h-11 flex items-center justify-between px-5 text-white">
        <span className="text-[15px]" style={{ fontFamily: 'Inter', fontWeight: 700 }}>9:41</span>
        <div className="flex items-center gap-1.5">
          <span className="text-[13px]">📶</span>
          <span className="text-[13px]">📶</span>
          <span className="text-[13px]">🔋</span>
        </div>
      </div>

      {/* Top Bar */}
      <div className="h-14 flex items-center justify-between px-5">
        <button
          onClick={() => navigate('/scanner')}
          className="text-[14px] text-white"
        >
          ← Retour
        </button>
        <h1 className="text-[17px] text-white" style={{ fontFamily: 'Inter', fontWeight: 700 }}>
          PharmaTrace
        </h1>
        <div className="w-16"></div>
      </div>

      {/* Icon Area */}
      <div className="flex justify-center mt-11">
        <div
          className="w-[92px] h-[92px] rounded-full bg-white flex items-center justify-center text-[50px]"
          style={{
            boxShadow: '0 0 0 8px rgba(255,255,255,0.20), 0 0 0 18px rgba(255,255,255,0.10)',
            color: '#C0392B',
            fontWeight: 700
          }}
        >
          ✗
        </div>
      </div>

      {/* Verdict */}
      <div className="px-6 mt-4.5 text-center">
        <h2 className="text-[34px] text-white" style={{ fontFamily: 'Inter', fontWeight: 900, letterSpacing: '1px' }}>
          ✗  NON TROUVÉ
        </h2>
        <p className="text-[18px] text-white mt-1.5" style={{ fontFamily: 'Inter', fontWeight: 900, opacity: 0.9 }}>
          MÉDICAMENT SUSPECT
        </p>
      </div>

      {/* Main Card */}
      <div
        className="mx-4 mt-5.5 bg-white rounded-2xl p-5.5"
        style={{ boxShadow: '0 8px 32px rgba(0,0,0,0.2)' }}
      >
        <div className="border-b pb-3.5 mb-4" style={{ borderColor: '#DCE6F0' }}>
          <h3 className="text-[13px]" style={{ color: '#C0392B', fontFamily: 'Inter', fontWeight: 700, textTransform: 'uppercase' }}>
            ⚠  MÉDICAMENT NON ENREGISTRÉ
          </h3>
        </div>

        <p className="text-[15px]" style={{ fontFamily: 'Inter', color: '#1A1A1A', lineHeight: 1.7 }}>
          Ce médicament n'est pas dans le registre officiel PharmaTrace.
        </p>

        {/* Do Not Consume Box */}
        <div className="rounded-[10px] px-4 py-4 mt-3.5 text-center" style={{ backgroundColor: '#FDE8E8' }}>
          <p className="text-[17px]" style={{ fontFamily: 'Inter', fontWeight: 900, color: '#C0392B' }}>
            ⛔  NE LE CONSOMMEZ PAS
          </p>
          <p className="text-[13px] mt-1" style={{ color: '#C0392B', opacity: 0.75 }}>
            Ne l'achetez pas.
          </p>
        </div>

        {/* Emergency Box */}
        <div className="rounded-[10px] px-5 py-4.5 mt-3 text-center" style={{ backgroundColor: '#1A3A5C' }}>
          <p className="text-[12px] text-white" style={{ opacity: 0.6 }}>
            Urgence sanitaire Niger
          </p>
          <p className="text-[48px] text-white mt-1" style={{ fontFamily: 'Inter', fontWeight: 900, lineHeight: 1 }}>
            15
          </p>
          <p className="text-[11px] text-white mt-1" style={{ opacity: 0.5 }}>
            Appelez pour signaler
          </p>
        </div>
      </div>

      {/* Bottom Buttons */}
      <div className="mx-4 mt-5 space-y-2.5">
        <button
          className="w-full h-[52px] rounded-lg bg-white text-[15px]"
          style={{
            color: '#C0392B',
            fontFamily: 'Inter',
            fontWeight: 700
          }}
        >
          Signaler ce médicament
        </button>
        <button
          onClick={() => navigate('/scanner')}
          className="w-full h-12 rounded-lg text-white text-[14px]"
          style={{
            backgroundColor: 'transparent',
            border: '1.5px solid rgba(255,255,255,0.45)',
            fontFamily: 'Inter',
            fontWeight: 600
          }}
        >
          Vérifier un autre médicament
        </button>
      </div>

      {/* Home Indicator */}
      <div className="flex justify-center mt-auto pb-2">
        <div className="w-[130px] h-1 rounded-sm bg-white" style={{ opacity: 0.15 }}></div>
      </div>
    </div>
  );
}
