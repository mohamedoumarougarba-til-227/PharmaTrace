import { createBrowserRouter } from 'react-router';
import { RootLayout } from './components/RootLayout';
import { LoginScreen } from './components/LoginScreen';
import { RegisterBatchScreen } from './components/RegisterBatchScreen';
import { QRCodeGeneratedScreen } from './components/QRCodeGeneratedScreen';
import { InitiateTransferScreen } from './components/InitiateTransferScreen';
import { IncomingTransfersScreen } from './components/IncomingTransfersScreen';
import { ReceiveBatchScreen } from './components/ReceiveBatchScreen';
import { StockScreen } from './components/StockScreen';
import { ScanMedicineScreen } from './components/ScanMedicineScreen';
import { AuthenticResultScreen } from './components/AuthenticResultScreen';
import { SuspectResultScreen } from './components/SuspectResultScreen';
import { FabricantAccountScreen } from './components/FabricantAccountScreen';
import { PharmacyAccountScreen } from './components/PharmacyAccountScreen';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <RootLayout />,
    children: [
      {
        index: true,
        element: <LoginScreen />,
      },
      {
        path: 'fabricant/nouveau-lot',
        element: <RegisterBatchScreen />,
      },
      {
        path: 'fabricant/qr-genere',
        element: <QRCodeGeneratedScreen />,
      },
      {
        path: 'fabricant/transfert',
        element: <InitiateTransferScreen />,
      },
      {
        path: 'fabricant/compte',
        element: <FabricantAccountScreen />,
      },
      {
        path: 'pharmacie/transferts',
        element: <IncomingTransfersScreen />,
      },
      {
        path: 'pharmacie/reception',
        element: <ReceiveBatchScreen />,
      },
      {
        path: 'pharmacie/stock',
        element: <StockScreen />,
      },
      {
        path: 'pharmacie/compte',
        element: <PharmacyAccountScreen />,
      },
      {
        path: 'scanner',
        element: <ScanMedicineScreen />,
      },
      {
        path: 'resultat/authentique',
        element: <AuthenticResultScreen />,
      },
      {
        path: 'resultat/suspect',
        element: <SuspectResultScreen />,
      },
    ],
  },
]);
