Generate 3 mobile frames (390x844px each) for the PharmaTrace FABRICANT 
(manufacturer) user. Apply global context.

This user is a licensed pharmaceutical manufacturer or importer in Niger.
They use their smartphone to register medicine batches, get a QR code, 
and send batches to pharmacies.

===== FRAME 1 : "Fabricant — Enregistrer un lot" =====

Background: #F7F9FC

TOP BAR (56px, background #1A3A5C, padding 0 20px, flex align-center):
  Left: nothing (home screen)
  Center: "PharmaTrace" — Inter Bold 17px, white
  Right: person icon + small dot indicator, white

WELCOME STRIP (background white, padding 16px 20px, 
  border-bottom 1px #DCE6F0):
  "Bonjour, Labo Niger Pharma 👋" — Inter SemiBold 15px, #1A3A5C
  "Fabricant agréé" — 12px, #27AE60, margin-top 2px

PAGE TITLE BLOCK (padding 20px 20px 0):
  "Enregistrer un lot" — Inter Bold 24px, #1A3A5C
  "Créez un nouveau lot de médicaments." — 
    14px, #666, margin-top 4px

FORM CARD (background white, radius 12px, shadow, 
  margin 16px 20px 0, padding 20px):

  Section label "MÉDICAMENT" — 11px, #2E6DA4, uppercase, 
    letter-spacing 1.5px, margin-bottom 14px

  Field 1:
    Label "Nom commercial *" — 13px, #1A1A1A, bold, margin-bottom 6px
    Input — full width, 52px height, border 2px #2E6DA4 (focused),
    radius 8px, padding 0 16px, value "Amoxicilline 500mg" 
    filled, Inter 15px #1A1A1A

  Field 2 (margin-top 14px):
    Label "Forme galénique"
    Dropdown — full width, 52px, border 1px #DCE6F0, radius 8px,
    value "Comprimé  ▼", 15px #1A1A1A

  Field 3 (margin-top 14px):
    Label "Dosage"
    Input — value "500 mg", border 1px #DCE6F0
    Helper below "Ex : 500mg, 250mg/5ml" — 11px #999

  Field 4 (margin-top 14px):
    Label "Quantité d'unités *"
    Input — number, value "2 000", border 1px #DCE6F0

  Divider line (1px #DCE6F0, margin 20px 0)

  Section label "IDENTIFICATION DU LOT"

  Field 5:
    Label "Numéro de lot officiel *"
    Input — value "FAB-2026-049", border 1px #DCE6F0
    Helper "Doit être unique dans le système" — 11px #999

  Field 6 (margin-top 14px):
    Label "Date de fabrication *"
    Input date — value "15 / 05 / 2026", calendar icon right,
    border 1px #DCE6F0

  Field 7 (margin-top 14px):
    Label "Date d'expiration *"
    Input date — value "15 / 05 / 2028", calendar icon right,
    border 2px #27AE60 (valid),
    Helper "✓ Valide — 2 ans" — 11px #27AE60

STICKY BOTTOM ACTION (position fixed bottom 64px, full width,
  background white, border-top 1px #DCE6F0, padding 12px 20px):
  Button "Générer le QR code →" — full width, height 52px,
  background #1A3A5C, white Inter Bold 16px, radius 8px,
  shadow 0 4px 16px rgba(26,58,92,0.3)

BOTTOM TAB BAR (64px, white, border-top 1px #DCE6F0, 
  shadow 0 -2px 8px rgba(0,0,0,0.06)):
  4 tabs centered, gap equal:
  Tab 1 active — icon "+" in #1A3A5C filled circle + 
    "Nouveau lot" — 10px #1A3A5C bold
  Tab 2 — icon grid + "Mes lots" — 10px #999
  Tab 3 — icon arrows + "Transferts" — 10px #999
  Tab 4 — icon person + "Compte" — 10px #999

===== FRAME 2 : "Fabricant — QR Code Généré" =====

Background: #F7F9FC

TOP BAR (56px, #1A3A5C):
  Left: "←" back arrow white
  Center: "PharmaTrace" white bold 17px
  Right: share icon white

SUCCESS BANNER (background #27AE60, padding 14px 20px):
  "✓  Lot enregistré avec succès !" — Inter Bold 15px, white
  "FAB-2026-049 — Amoxicilline 500mg" — 13px, white opacity 80%, 
    margin-top 3px

QR CARD (background white, radius 16px, shadow,
  margin 16px 20px 0, padding 28px, align-center, 
  flex column items-center):
  
  Label "QR CODE DE TRAÇABILITÉ" — 11px, #2E6DA4, uppercase,
    letter-spacing 1.5px, text-align center

  QR code image — 240x240px, sharp black-and-white QR pattern,
    border 1px #DCE6F0, radius 8px, margin-top 16px

  "FAB-2026-049" — Inter Bold 15px, #1A3A5C, 
    text-align center, margin-top 14px
  "Amoxicilline 500mg" — 13px, #666, text-align center, margin-top 4px

  Button row (full width, gap 10px, margin-top 20px):
    "⬇  Télécharger" — full width, white bg, border 1px #DCE6F0,
    #1A3A5C text, height 48px, radius 8px, Inter SemiBold 14px
    "🖨  Imprimer" — same style, margin-top 8px

INFO CARD (background white, radius 12px, shadow,
  margin 16px 20px 0, padding 20px):
  
  Title "Détails du lot" — Inter SemiBold 15px, #1A3A5C,
    border-bottom 1px #DCE6F0, padding-bottom 12px, margin-bottom 16px

  Info rows (each 40px, border-bottom 1px #F7F9FC,
    flex space-between, 14px):
    "Médicament"    → "Amoxicilline 500mg" bold
    "N° de lot"     → "FAB-2026-049" blue bold
    "Quantité"      → "2 000 unités"
    "Fabrication"   → "15/05/2026"
    "Expiration"    → "15/05/2028" green bold
    "Statut"        → green pill "En stock ✓"

HASH BLOCK (background #1A3A5C, radius 10px, 
  margin 12px 20px 0, padding 16px 18px):
  "🔐  EMPREINTE SHA-256" — white 10px uppercase opacity 60%,
    letter-spacing 1.5px
  "a3f8b2c9d4e61f07..." — white mono 13px bold, margin-top 6px,
    word-break break-all, opacity 90%
  "Immuable — ne peut jamais être falsifiée" — 
    white italic 11px opacity 50%, margin-top 6px

STICKY BOTTOM ACTION (fixed bottom 64px, white, 
  border-top 1px #DCE6F0, padding 12px 20px):
  "Initier un transfert →" — full width, 52px, #1A3A5C bg,
    white bold 16px, radius 8px

BOTTOM TAB BAR (same as Frame 1, active: Mes lots)

===== FRAME 3 : "Fabricant — Initier un Transfert" =====

Background: #F7F9FC

TOP BAR (56px, #1A3A5C):
  Left: "←" back arrow white
  Center: "Transfert" white bold 17px
  Right: nothing

LOT RECAP CARD (background #EEF4FB, border 1px #DCE6F0, 
  radius 12px, margin 16px 20px 0, padding 16px 18px):
  "LOT À TRANSFÉRER" — 10px, #2E6DA4, uppercase, letter-spacing 1.5px
  "Amoxicilline 500mg" — Inter Bold 18px, #1A3A5C, margin-top 6px
  Row (flex, gap 8px, margin-top 6px, align-center):
    Navy badge "FAB-2026-049" — bg #1A3A5C, white 11px, 
      padding 3px 10px, radius 4px
    "2 000 unités disponibles" — 13px, #27AE60

FORM CARD (background white, radius 12px, shadow,
  margin 16px 20px 0, padding 20px):

  Field 1:
    Label "Pharmacie destinataire *" — 13px bold #1A1A1A,
      margin-bottom 8px
    Dropdown (full width, 52px, border 1px #DCE6F0, radius 8px,
      padding 0 14px):
      Left: 💊 emoji
      Value "Pharmacie Centrale de Niamey" — 15px #1A1A1A
      Right: "▼" — #666
    
    OPTIONS LIST visible open below dropdown 
      (white, radius 8px, shadow, border 1px #DCE6F0, 
       margin-top 4px, overflow hidden):
      Option highlighted (bg #EEF4FB):
        "💊  Pharmacie Centrale de Niamey" — 14px bold #1A3A5C
        "Avenue du Fleuve, Niamey" — 12px #999
        Checkmark ✓ right in #2E6DA4
      Option normal:
        "💊  Pharmacie du Marché Katako"
        "Rue du Commerce, Niamey" — 12px #999
      Option:
        "🏥  Centre de Santé Yantala"
        "Quartier Yantala, Niamey" — 12px #999

  Field 2 (margin-top 20px):
    Label "Quantité à transférer *" — 13px bold
    Row (flex, gap 10px, align-center):
      Button "−" — 48x48px, border 1px #DCE6F0, radius 8px, 
        #1A1A1A bold 20px
      Input — flex-1, 52px, border 1px #DCE6F0, radius 8px,
        value "500" center-aligned, bold 18px
      Button "+" — same style
    Helper "Maximum disponible : 2 000 unités" — 
      12px #999, margin-top 6px

  Field 3 (margin-top 20px):
    Label "Notes / Bon de livraison" 13px bold + 
      " (optionnel)" 12px #999
    Textarea — full width, 88px, border 1px #DCE6F0, radius 8px,
      padding 12px 14px, 
      placeholder "N° bon de livraison, instructions..." 
      in #BBB 14px

  WARNING BOX (background #FEF4E0, border-left 4px solid #E67E22,
    border-radius 0 8px 8px 0, padding 12px 14px, margin-top 16px):
    "⚠️  Le lot passera en statut En transit. La pharmacie 
    devra confirmer la réception par scan." — 
    13px #666, line-height 1.6

STICKY BOTTOM ACTION (fixed bottom 64px, white, 
  border-top 1px #DCE6F0, padding 12px 20px):
  "Confirmer le transfert →" — full width, 52px, 
    #1A3A5C bg, white bold 16px, radius 8px

BOTTOM TAB BAR (active: Transferts)
