Generate 3 mobile frames (390x844px each) for the PharmaTrace PHARMACIE 
(pharmacy) user. Apply global context.

This user is a pharmacist or health worker in Niger. They receive medicine 
batches on their phone, confirm reception by scanning QR codes, and manage 
their stock. Phase 2 explicitly requires a mobile app for this user.

===== FRAME 1 : "Pharmacie — Transferts entrants" =====

Background: #F7F9FC

TOP BAR (56px, #1A3A5C, padding 0 20px):
  Left: nothing
  Center: "PharmaTrace" white bold 17px
  Right: bell icon white with orange badge "3" — 
    circle 18px, bg #E67E22, white 10px bold

WELCOME STRIP (white, padding 16px 20px, border-bottom 1px #DCE6F0):
  Row (flex, space-between, align-center):
    Block left:
      "Pharmacie Centrale" — Inter SemiBold 15px, #1A3A5C
      "Pharmacie agréée" — 12px, #27AE60, margin-top 2px
    Block right:
      "23 mai 2026" — 12px #999

PAGE TITLE BLOCK (padding 16px 20px 0):
  Row (flex, align-center, gap 10px):
    "Transferts entrants" — Inter Bold 22px, #1A3A5C
    Orange pill badge "3" — bg #FEF4E0, text #E67E22, 
      13px bold, padding 3px 10px, radius 20px

ORANGE STRIP (background #FEF4E0, border 1px #F5D5B0,
  radius 8px, margin 12px 20px 0, padding 12px 16px):
  "⚡  3 lots attendent votre confirmation." — 
    Inter SemiBold 13px, #E67E22

TRANSFER CARDS LIST (padding 0 20px, margin-top 14px, gap 12px):

CARD 1 (white, radius 12px, shadow, padding 18px,
  border-left 5px solid #E67E22):
  Row top (flex, space-between, align-start):
    Left:
      Orange pill "EN ATTENTE" — bg #FEF4E0, text #E67E22,
        11px bold uppercase
      "Amoxicilline 500mg" — Inter Bold 17px, #1A3A5C, margin-top 6px
      "500 unités  •  Dosage : 500mg" — 13px #666, margin-top 3px
    Right:
      "Il y a 2j" — 12px #BBB, text-align right
  
  Row middle (flex, gap 6px, align-center, 
    margin-top 12px, padding-top 12px, 
    border-top 1px #F7F9FC):
    Factory icon 14px #999 + 
    "De : Laboratoire Niger Pharma" — 13px #555
  
  Row bottom (flex, gap 8px, margin-top 12px, 
    padding-top 12px, border-top 1px #F7F9FC):
    "Refuser" — flex-1, white bg, border 1px #C0392B,
      #C0392B text, height 42px, radius 8px, 
      Inter SemiBold 14px, text-center
    "✓ Réceptionner" — flex-2, bg #27AE60, white bold 14px,
      height 42px, radius 8px, text-center

CARD 2 (same structure, border-left #E67E22):
  "Paracétamol 1000mg" — 300 unités
  "De : Laboratoire Niger Pharma" — "Il y a 1j"
  Same action buttons

CARD 3 (same structure):
  "Artéméther / Luméfantrine 20mg" — 1000 unités
  "De : Laboratoire Niger Pharma" — "Aujourd'hui"
  Same action buttons

BOTTOM TAB BAR (64px, white, border-top 1px #DCE6F0):
  "📥 Transferts" active #1A3A5C bold + 
    orange dot | "📦 Stock" #999 | "🔍 Scan" #999 | "👤 Compte" #999

===== FRAME 2 : "Pharmacie — Réceptionner un Lot" =====

Background: #F7F9FC

TOP BAR (56px, #1A3A5C):
  Left: "←" back arrow white
  Center: "Réception du lot" white bold 17px
  Right: nothing

LOT INFO CARD (background #EEF4FB, border 1px #DCE6F0,
  radius 12px, margin 16px 20px 0, padding 16px 18px):
  "LOT À RÉCEPTIONNER" — 10px #2E6DA4 uppercase letter-spacing 1.5px
  "Amoxicilline 500mg" — Inter Bold 17px, #1A3A5C, margin-top 6px
  Row (gap 8px, flex, align-center, margin-top 6px):
    Navy badge "FAB-2026-049"
    "500 unités" — 13px #666

STEP INDICATOR (flex, align-center, padding 0 20px, margin-top 20px):
  Step 1 active:
    Circle 32px filled #1A3A5C, white "1" bold 14px
    "Scanner le lot" — 13px #1A3A5C bold, margin-left 8px
  Line — 60px, 2px #DCE6F0 dashed, flex-1, margin 0 12px
  Step 2 inactive:
    Circle 32px border 2px #DCE6F0, #BBB "2" 14px
    "Confirmer" — 13px #BBB, margin-left 8px

SCANNER ZONE (border 2px dashed #2E6DA4, radius 14px,
  background white, margin 16px 20px 0, 
  height 200px, flex column, align-center, 
  justify-center, padding 20px):
  Camera icon 40px #2E6DA4
  "Activer la caméra" — Inter Medium 16px #2E6DA4, margin-top 12px
  "Pointez vers le QR code du lot reçu" — 
    13px #999, margin-top 6px, text-align center

DIVIDER (flex, align-center, gap 10px, 
  padding 0 20px, margin-top 20px):
  Line #DCE6F0 flex-1
  "ou saisir manuellement" — 12px #BBB
  Line #DCE6F0 flex-1

INPUT ROW (padding 0 20px, margin-top 14px, flex, gap 8px):
  Input (flex-1, 52px, border 1px #DCE6F0, radius 8px, 
    padding 0 14px, placeholder "N° du lot..." 14px #BBB)
  Button "OK" (bg #2E6DA4, white bold, 52px square, radius 8px)

NOTES FIELD (padding 0 20px, margin-top 16px):
  Label "Notes (optionnel)" — 13px bold #1A1A1A, margin-bottom 6px
  Textarea — full width, 80px, border 1px #DCE6F0, radius 8px,
    padding 10px 14px,
    placeholder "Ex: colis intact, température correcte..." 
    14px #BBB

STICKY BOTTOM ACTION (fixed bottom 0, white,
  border-top 1px #DCE6F0, padding 12px 20px, 
  padding-bottom 28px):
  "✓  Confirmer la réception" — full width, 52px,
    bg #27AE60, white Inter Bold 16px, radius 8px,
    shadow 0 4px 16px rgba(39,174,96,0.3)

===== FRAME 3 : "Pharmacie — Mon Stock" =====

Background: #F7F9FC

TOP BAR (56px, #1A3A5C):
  Left: nothing
  Center: "Mon Stock" white bold 17px
  Right: search icon white

STOCK SUMMARY ROW (white, padding 16px 20px, 
  border-bottom 1px #DCE6F0):
  3 mini counters (flex, space-between):
    Counter 1: "27" Inter Black 24px #1A3A5C + 
      "En stock" 11px #666, text-center
    Divider 1px #DCE6F0 vertical
    Counter 2: "2" Inter Black 24px #E67E22 + 
      "Exp. bientôt" 11px #666, text-center
    Divider
    Counter 3: "0" Inter Black 24px #27AE60 + 
      "Alertes" 11px #666, text-center

WARNING STRIP (background #FEF4E0, border-left 4px #E67E22,
  border-radius 0 8px 8px 0, margin 14px 20px 0, padding 12px 14px):
  "⚠️  2 médicaments expirent dans moins de 30 jours." — 
    13px #E67E22 SemiBold

STOCK CARDS LIST (padding 0 20px, margin-top 14px, gap 10px):

CARD 1 — NORMAL STOCK (white, radius 12px, shadow, padding 18px,
  border-left 4px solid #27AE60):
  Row top (flex, space-between, align-start):
    Left:
      "Amoxicilline 500mg" — Inter Bold 16px, #1A3A5C
      "N° FAB-2026-049  •  500mg  •  Comprimé" — 12px #666, 
        margin-top 4px
    Right:
      Green pill "En stock" — bg #E8F8EC, text #27AE60, 
        11px bold uppercase, padding 3px 10px
  
  Row bottom (flex, space-between, align-center,
    margin-top 12px, padding-top 12px, 
    border-top 1px #F7F9FC):
    Left:
      "500 unités restantes" — 13px #555
    Right:
      "Exp : 15/01/2028" — 12px #999

CARD 2 — NORMAL: 
  "Paracétamol 1000mg" — FAB-2026-048 — 300 unités
  "Exp : 20/03/2028"

CARD 3 — EXPIRING SOON (border-left #E67E22, 
  background #FFFBF5):
  Row top:
    Left:
      "Cotrimoxazole 480mg" — Inter Bold 16px #1A3A5C
      "N° FAB-2026-030  •  480mg  •  Comprimé" — 12px #666
    Right:
      Orange pill "Expire bientôt ⚠"
  Row bottom:
    "45 unités restantes" — 13px #555
    "Exp : 15/06/2026" — 12px #E67E22 bold
  
  Row actions (flex, gap 8px, margin-top 12px):
    "Archiver" — flex-1, white bg, border 1px #DCE6F0,
      #666 text, height 38px, radius 8px, 14px
    "🔍 Vérifier" — flex-1, bg #EEF4FB, #2E6DA4 text bold,
      height 38px, radius 8px, 14px

CARD 4 — ARCHIVED (opacity 45%):
  "Aspirine 500mg" — FAB-2025-010
  Gray pill "Archivé"
  "0 unités  •  Exp : 01/01/2025 (périmé)"

BOTTOM TAB BAR (active: Stock)
